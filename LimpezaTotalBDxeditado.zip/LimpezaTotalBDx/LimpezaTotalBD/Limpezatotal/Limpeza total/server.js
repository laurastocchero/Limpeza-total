const http = require("http");
const mysql = require("mysql2/promise");

const conexao = {
    host: "localhost",
    user: "limpeza_app",
    password: process.env.DB_PASSWORD,
  database: "limpeza_total",
    port: 3306
};

const servidor = http.createServer(async (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Content-Type", "application/json; charset=utf-8");

    if (req.url === "/api/produtos" && req.method === "GET") {
        try {
            const banco = await mysql.createConnection(conexao);
            const [produtos] = await banco.execute(
                "SELECT id, nome, descricao, categoria, preco, estoque FROM produtos ORDER BY id"
            );
            await banco.end();

            res.writeHead(200);
            res.end(JSON.stringify(produtos));
        } catch (erro) {
            console.error("Erro no banco:", erro.message);
            res.writeHead(500);
            res.end(JSON.stringify({ erro: "Não foi possível consultar os produtos." }));
        }
        return;
    }

    res.writeHead(404);
    res.end(JSON.stringify({ erro: "Rota não encontrada." }));
});

servidor.listen(3000, () => {
    console.log("API Limpeza Total iniciada!");
    console.log("Endereço: http://localhost:3000/api/produtos");
});