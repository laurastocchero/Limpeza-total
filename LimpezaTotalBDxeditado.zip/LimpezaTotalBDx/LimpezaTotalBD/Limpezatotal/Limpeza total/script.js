
(function () {
    "use strict";

    var CHAVE = "carrinhoLimpezaTotal";

    function formatar(valor) {
        return valor.toLocaleString("pt-BR", {
            style: "currency",
            currency: "BRL"
        });
    }

    function normalizar(texto) {
        return String(texto).toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .trim();
    }

    function lerPreco(texto) {
        return Number(
            texto.replace(/[^\d,]/g, "").replace(",", ".")
        );
    }

    var nomesCorrigidos = {
        "lava loucas neutro 5l": "Lava Louças Neutro 5L",
        "esponja para louca - 3un.": "Esponja para Louça - 3un.",
        "esponja de aco": "Esponja de Aço",
        "limpa aluminio 5l": "Limpa Alumínio 5L",
        "limpa aluminio 850ml": "Limpa Alumínio 850ml",
        "desinfetante uau antibacterias 2l": "Desinfetante UAU Antibactérias 2L",
        "agua sanitaria 5l": "Água Sanitária 5L",
        "agua sanitaria 2l": "Água Sanitária 2L",
        "hipoclorito de sodio 5l": "Hipoclorito de Sódio 5L",
        "escova sanitaria com suporte": "Escova Sanitária com Suporte",
        "sabonete liquido pimenta rosa": "Sabonete Líquido Pimenta Rosa",
        "sabonete flor de laranjeira": "Sabonete Flor de Laranjeira",
        "sabonete liquido bergamota citrus": "Sabonete Líquido Bergamota Citrus",
        "sabonete liquido agua de coco": "Sabonete Líquido Água de Coco",
        "lava roupas rosas e seducao 3l": "Lava Roupas Rosas e Sedução 3L",
        "lava roupas liquido uau premium coco & vanilla 1,7l": "Lava Roupas Líquido UAU Premium Coco & Vanilla 1,7L",
        "lava roupas liquido uau active 1,7l": "Lava Roupas Líquido UAU Active 1,7L",
        "lava roupas liquido clariel care clarilimp 5l": "Lava Roupas Líquido Clariel Care Clarilimp 5L",
        "lava roupas liquido coconut 5l": "Lava Roupas Líquido Coconut 5L",
        "bicarbonato de sodio 1kg": "Bicarbonato de Sódio 1kg",
        "pos obra 5l": "Pós-Obra 5L",
        "uau essencia concentrada 130ml": "UAU Essência Concentrada 130ml",
        "saponaceo": "Saponáceo",
        "lustra moveis 200ml": "Lustra Móveis 200ml",
        "alcool gel 70": "Álcool Gel 70",
        "balde com alca de ferro 16l": "Balde com Alça de Ferro 16L",
        "pa de mao": "Pá de Mão",
        "vassoura varre facil condor": "Vassoura Varre Fácil Condor",
        "vassoura de pelo sintetico": "Vassoura de Pelo Sintético",
        "vassoura caipira de piacava": "Vassoura Caipira de Piaçava",
        "rodo plastico 30cm c/cabo": "Rodo Plástico 30cm C/Cabo",
        "rodo plastico 40cm c/cabo": "Rodo Plástico 40cm C/Cabo",
        "cabo de vassoura/rodo reforcado": "Cabo de Vassoura/Rodo Reforçado",
        "mascara descartavel": "Máscara Descartável"
    };

    function nomeParaExibir(nomeOriginal) {
        var chave = normalizar(nomeOriginal);
        return nomesCorrigidos[chave] || nomeOriginal;
    }


    var carrinho = [];

    try {
        var salvo = JSON.parse(localStorage.getItem(CHAVE));

        if (Array.isArray(salvo)) {
            carrinho = salvo.filter(function (i) {
                return i && i.nome &&
                    Number.isFinite(i.preco) &&
                    i.quantidade > 0;
            });
        }
    } catch (e) {
        carrinho = [];
    }

    function salvarCarrinho() {
        try {
            localStorage.setItem(CHAVE, JSON.stringify(carrinho));
        } catch (e) { }
    }

    function contarItens() {
        return carrinho.reduce(function (soma, i) {
            return soma + i.quantidade;
        }, 0);
    }

    function totalCarrinho() {
        return carrinho.reduce(function (soma, i) {
            return soma + i.preco * i.quantidade;
        }, 0);
    }


    var aviso, temporizador;

    function mostrarAviso(mensagem) {
        if (!aviso) {
            aviso = document.createElement("div");
            aviso.className = "aviso";
            aviso.setAttribute("role", "status");
            document.body.appendChild(aviso);
        }

        aviso.textContent = mensagem;
        aviso.classList.add("visivel");

        clearTimeout(temporizador);

        temporizador = setTimeout(function () {
            aviso.classList.remove("visivel");
        }, 2200);
    }


    function atualizarContador() {
        var qtd = contarItens();

        document.querySelectorAll(
            'nav a[href="carrinho.html"]'
        ).forEach(function (link) {
            var marca = link.querySelector(".contador-carrinho");

            if (!marca) {
                marca = document.createElement("span");
                marca.className = "contador-carrinho";
                link.appendChild(marca);
            }

            marca.textContent = qtd;
            marca.hidden = qtd === 0;
        });
    }


    function adicionarCarrinho(produto) {
        var titulo = produto.querySelector("h3");

        var campoPreco =
            produto.querySelector(".preco-oferta") ||
            produto.querySelector(".preco");

        if (!titulo || !campoPreco) {
            mostrarAviso("Não foi possível adicionar este produto.");
            return;
        }

        var nome = titulo.textContent.replace(/\s+/g, " ").trim();
        var preco = lerPreco(campoPreco.textContent);

        if (!Number.isFinite(preco) || preco <= 0) {
            mostrarAviso("O preço deste produto está inválido.");
            return;
        }

        var existente = carrinho.find(function (i) {
            return i.nome === nome && i.preco === preco;
        });

        if (existente) {
            existente.quantidade++;
        } else {
            carrinho.push({
                nome: nome,
                preco: preco,
                quantidade: 1
            });
        }

        salvarCarrinho();
        atualizarTudo();

        mostrarAviso("✔ " + nome + " foi adicionado ao carrinho!");
    }

    document.addEventListener("click", function (e) {
        var botao = e.target.closest(".produto .comprar");

        if (botao) {
            e.preventDefault();
            adicionarCarrinho(botao.closest(".produto"));
        }
    });

    function criar(tag, classe, texto) {
        var el = document.createElement(tag);

        if (classe) el.className = classe;
        if (texto !== undefined) el.textContent = texto;

        return el;
    }


    function renderizarCarrinho() {
        var lista = document.getElementById("itensCarrinho");

        if (!lista) return;

        var vazio = document.getElementById("carrinhoVazio");
        var cheio = document.getElementById("carrinhoCheio");

        if (vazio) vazio.hidden = carrinho.length > 0;
        if (cheio) cheio.hidden = carrinho.length === 0;

        lista.innerHTML = "";

        carrinho.forEach(function (item) {
            var linha = criar("div", "item-carrinho");

            var info = criar("div", "item-info");

            info.appendChild(criar("strong", "", item.nome));

            info.appendChild(
                criar("small", "", formatar(item.preco) + " cada")
            );

            var controles = criar("div", "item-controles");

            var menos = criar("button", "", "−");
            var qtd = criar("span", "qtd", String(item.quantidade));
            var mais = criar("button", "", "+");
            var remover = criar("button", "", "Remover");

            [menos, mais, remover].forEach(function (b) {
                b.type = "button";
            });

            menos.setAttribute("aria-label", "Diminuir quantidade");
            mais.setAttribute("aria-label", "Aumentar quantidade");

            menos.addEventListener("click", function () {
                item.quantidade--;

                if (item.quantidade <= 0) {
                    carrinho.splice(carrinho.indexOf(item), 1);
                }

                salvarCarrinho();
                atualizarTudo();
            });

            mais.addEventListener("click", function () {
                item.quantidade++;
                salvarCarrinho();
                atualizarTudo();
            });

            remover.addEventListener("click", function () {
                carrinho.splice(carrinho.indexOf(item), 1);
                salvarCarrinho();
                atualizarTudo();
            });

            controles.append(menos, qtd, mais, remover);

            var subtotal = criar(
                "div",
                "item-subtotal",
                formatar(item.preco * item.quantidade)
            );

            linha.append(info, controles, subtotal);
            lista.appendChild(linha);
        });

        var total = document.getElementById("totalCarrinho");

        if (total) {
            total.textContent = "Total: " + formatar(totalCarrinho());
        }
    }

    var botaoLimpar = document.getElementById("limparCarrinho");

    if (botaoLimpar) {
        botaoLimpar.addEventListener("click", function () {
            if (!confirm("Deseja remover todos os produtos do carrinho?")) {
                return;
            }

            carrinho = [];
            salvarCarrinho();
            atualizarTudo();
        });
    }

    function atualizarTudo() {
        atualizarContador();
        renderizarCarrinho();
    }

    var campoPesquisa = document.querySelector(".pesquisa input");
    var botaoPesquisa = document.querySelector(".pesquisa button");
    var produtos = document.querySelectorAll(".produto");
    var mensagemVazia = null;

    function filtrar(termo) {
        var busca = normalizar(termo);
        var encontrados = 0;

        produtos.forEach(function (produto) {
            var titulo = produto.querySelector("h3");

            if (!titulo) return;

            var nome = normalizar(titulo.textContent);
            var combina = busca === "" || nome.indexOf(busca) !== -1;

            produto.style.display = combina ? "" : "none";

            if (combina) encontrados++;
        });

        document.querySelectorAll(
            ".categoria-produtos, .ofertas-produtos"
        ).forEach(function (secao) {
            var visiveis = Array.prototype.some.call(
                secao.querySelectorAll(".produto"),
                function (p) {
                    return p.style.display !== "none";
                }
            );

            secao.style.display = visiveis ? "" : "none";
        });

        if (!mensagemVazia) {
            mensagemVazia = criar("p", "sem-resultados");

            var rodape =
                document.querySelector(".voltar") ||
                document.querySelector("footer");

            if (rodape && rodape.parentNode) {
                rodape.parentNode.insertBefore(mensagemVazia, rodape);
            }
        }

        if (mensagemVazia) {
            mensagemVazia.hidden = encontrados !== 0;

            mensagemVazia.textContent =
                'Nenhum produto encontrado para "' + termo.trim() + '".';
        }
    }

    function pesquisar() {
        if (!campoPesquisa) return;

        var termo = campoPesquisa.value;

        if (produtos.length === 0) {
            if (termo.trim() === "") return;

            window.location.href =
                "produtos.html?busca=" + encodeURIComponent(termo.trim());

            return;
        }

        filtrar(termo);
    }

    if (campoPesquisa) {
        if (botaoPesquisa) {
            botaoPesquisa.addEventListener("click", pesquisar);
        }

        campoPesquisa.addEventListener("keydown", function (e) {
            if (e.key === "Enter") pesquisar();
        });

        if (produtos.length > 0) {
            campoPesquisa.addEventListener("input", pesquisar);

            var parametro =
                new URLSearchParams(window.location.search).get("busca");

            if (parametro) {
                campoPesquisa.value = parametro;
                filtrar(parametro);
            }
        }
    }


    document.querySelectorAll(".oferta-card").forEach(function (card) {
        var antigo = card.querySelector(".preco-antigo");
        var atual = card.querySelector(".preco-oferta");
        var etiqueta = card.querySelector(".desconto");

        if (!antigo || !atual || !etiqueta) return;

        var a = lerPreco(antigo.textContent);
        var b = lerPreco(atual.textContent);

        if (a > 0 && b > 0 && b < a) {
            etiqueta.textContent =
                "-" + Math.round((1 - b / a) * 100) + "%";
        }
    });


    function reserva(img) {
        if (img.dataset.reserva) return;

        img.dataset.reserva = "1";
        img.classList.add("sem-foto");
        img.src = "logo.jpeg";
    }

    document.querySelectorAll(".imagem-produto img").forEach(function (img) {
        img.addEventListener("error", function () {
            reserva(img);
        });

        if (img.complete && img.naturalWidth === 0) {
            reserva(img);
        }
    });

    var paginaAtual =
        window.location.pathname.split("/").pop() || "index.html";

    document.querySelectorAll("nav a").forEach(function (link) {
        var destino = link.getAttribute("href");

        if (destino === paginaAtual) {
            link.classList.add("ativo");
        }
    });

    function carregarProdutosDoBanco() {
        fetch("http://localhost:3000/api/produtos")
            .then(function (resposta) {
                if (!resposta.ok) {
                    throw new Error("Erro na API");
                }

                return resposta.json();
            })
            .then(function (dados) {

                var imagens = {};

                document.querySelectorAll(".produto").forEach(function (card) {
                    var nomeOriginal = card.querySelector("h3");
                    var foto = card.querySelector("img");

                    if (nomeOriginal && foto) {
                        imagens[normalizar(nomeOriginal.textContent)] =
                            foto.getAttribute("src");
                    }
                });

                imagens[normalizar("Prendedor de Roupas - 36 un.")] =
                    "imagens/prendedor36.jpeg";

                imagens[normalizar("Prendedor de Roupas - 12 un.")] =
                    "imagens/prendedor12.jpeg";

                imagens[normalizar("Detergente Neutro")] =
                    "imagens/lavaloucaneutro.jpeg";


                var categorias = {
                    "cozinha": "cozinha",
                    "banheiro": "banheiro",
                    "roupas": "roupas",
                    "pisos": "pisos",
                    "limpeza geral": "limpeza-geral",
                    "acessorios": "acessorios"
                };

                var listas = document.querySelectorAll(".lista-produtos");

                listas.forEach(function (lista) {
                    lista.innerHTML = "";
                });


                dados.forEach(function (item) {

                    if (normalizar(item.nome) === "detergente neutro") {
                        return;
                    }

                    var categoria = normalizar(item.categoria);
                    var id = categorias[categoria] || "limpeza-geral";

                    var lista = document.querySelector(
                        "#" + id + " .lista-produtos"
                    );

                    if (!lista) return;

                    var card = document.createElement("div");
                    card.className = "produto";

                    var areaImagem = document.createElement("div");
                    areaImagem.className = "imagem-produto";

                    var foto = document.createElement("img");

                    foto.src =
                        imagens[normalizar(item.nome)] || "logo.jpeg";

                    foto.alt = nomeParaExibir(item.nome);

                    foto.addEventListener("error", function () {
                        reserva(foto);
                    });

                    areaImagem.appendChild(foto);

                    var nome = document.createElement("h3");
                    nome.textContent = nomeParaExibir(item.nome);

                    var preco = document.createElement("p");
                    preco.className = "preco";
                    preco.textContent = formatar(Number(item.preco));

                    var estoque = document.createElement("p");
                    estoque.className = "estoque";
                    estoque.textContent = "Estoque: " + item.estoque;

                    var botao = document.createElement("button");
                    botao.className = "comprar";
                    botao.type = "button";
                    botao.textContent = "Comprar";

                    card.append(
                        areaImagem,
                        nome,
                        preco,
                        estoque,
                        botao
                    );

                    lista.appendChild(card);
                });

                produtos = document.querySelectorAll(".produto");

                filtrar(campoPesquisa ? campoPesquisa.value : "");

                atualizarTudo();

                console.log(
                    "Produtos carregados do banco:",
                    dados.length
                );
            })
            .catch(function (erro) {
                console.error(
                    "Erro ao carregar produtos do banco:",
                    erro
                );

                mostrarAviso(
                    "Não foi possível conectar ao banco de dados."
                );
            });
    }

    atualizarTudo();
    carregarProdutosDoBanco();

})();
