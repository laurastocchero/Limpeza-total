-- MySQL dump 10.13  Distrib 26.10.0, for Win64 (x86_64)
--
-- Host: localhost    Database: limpeza_total_teste
-- ------------------------------------------------------
-- Server version	26.10.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `descricao` text,
  `categoria` varchar(100) DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `estoque` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'Detergente Neutro','Detergente liquido para limpeza diaria','Cozinha',2.99,38),(2,'Agua sanitaria 2L','Agua sanitaria para limpeza e desinfeccao, embalagem de 2 litros','Limpeza Geral',5.50,32),(3,'Lava Loucas Neutro 5L','Lava Loucas Neutro 5L para limpeza e uso domestico.','Cozinha',24.90,35),(4,'Esponja para Louca - 3un.','Esponja para Louca - 3un. para limpeza e uso domestico.','Cozinha',3.99,71),(5,'Esponja de Aco','Esponja de Aco para limpeza e uso domestico.','Cozinha',3.50,56),(6,'Esponja de Limpeza Pesada','Esponja de Limpeza Pesada para limpeza e uso domestico.','Cozinha',5.00,60),(7,'Limpador Desengordurante 500ml','Limpador Desengordurante 500ml para limpeza e uso domestico.','Cozinha',9.90,30),(8,'Limpa Aluminio 5L','Limpa Aluminio 5L para limpeza e uso domestico.','Cozinha',29.90,51),(9,'Limpa Aluminio 850ml','Limpa Aluminio 850ml para limpeza e uso domestico.','Cozinha',9.90,66),(10,'Guardanapo 50 un.','Guardanapo 50 un. para limpeza e uso domestico.','Cozinha',2.00,75),(11,'Desengordurante 500ml','Desengordurante 500ml para limpeza e uso domestico.','Cozinha',9.90,79),(12,'Diabo Verde','Diabo Verde para limpeza e uso domestico.','Banheiro',23.00,67),(13,'Detergente Clorado','Detergente Clorado para limpeza e uso domestico.','Banheiro',32.00,89),(14,'Desinfetante UAU Antibacterias 2L','Desinfetante UAU Antibacterias 2L para limpeza e uso domestico.','Banheiro',9.99,52),(15,'Agua Sanitaria 5L','Agua Sanitaria 5L para limpeza e uso domestico.','Banheiro',12.00,73),(16,'Hipoclorito de Sodio 5L','Hipoclorito de Sodio 5L para limpeza e uso domestico.','Banheiro',34.00,19),(17,'Escova Sanitaria com Suporte','Escova Sanitaria com Suporte para limpeza e uso domestico.','Banheiro',12.00,49),(18,'Rodinho de Pia','Rodinho de Pia para limpeza e uso domestico.','Banheiro',3.50,85),(19,'Sabonete Liquido Pimenta Rosa','Sabonete Liquido Pimenta Rosa para limpeza e uso domestico.','Banheiro',12.90,89),(20,'Sabonete Flor de Laranjeira','Sabonete Flor de Laranjeira para limpeza e uso domestico.','Banheiro',16.90,88),(21,'Sabonete Liquido Bergamota Citrus','Sabonete Liquido Bergamota Citrus para limpeza e uso domestico.','Banheiro',14.90,71),(22,'Sabonete Liquido Agua de Coco','Sabonete Liquido Agua de Coco para limpeza e uso domestico.','Banheiro',14.90,85),(23,'Lava Roupas Uau 2.7L Perfumado Premium','Lava Roupas Uau 2.7L Perfumado Premium para limpeza e uso domestico.','Roupas',32.00,17),(24,'Lava Roupas coco & vanilla 750ml','Lava Roupas coco & vanilla 750ml para limpeza e uso domestico.','Roupas',10.90,97),(25,'Lava Roupas Rosas e Seducao 3L','Lava Roupas Rosas e Seducao 3L para limpeza e uso domestico.','Roupas',32.00,57),(26,'Lava Roupas Liquido UAU Premium Coco & Vanilla 1,7L','Lava Roupas Liquido UAU Premium Coco & Vanilla 1,7L para limpeza e uso domestico.','Roupas',19.90,78),(27,'Lava Roupas Liquido UAU Active 1,7L','Lava Roupas Liquido UAU Active 1,7L para limpeza e uso domestico.','Roupas',19.90,28),(28,'Lava Roupas Liquido Clariel Care Clarilimp 5L','Lava Roupas Liquido Clariel Care Clarilimp 5L para limpeza e uso domestico.','Roupas',27.00,77),(29,'Lava Roupas Blue Care Clarilimp 5L','Lava Roupas Blue Care Clarilimp 5L para limpeza e uso domestico.','Roupas',22.00,21),(30,'Lava Roupas Liquido Coconut 5L','Lava Roupas Liquido Coconut 5L para limpeza e uso domestico.','Roupas',27.00,43),(31,'Lava Roupas Active 800ml','Lava Roupas Active 800ml para limpeza e uso domestico.','Roupas',12.99,53),(32,'Amaciante Concentrado UAU 500ml','Amaciante Concentrado UAU 500ml para limpeza e uso domestico.','Roupas',9.90,34),(33,'Percarbonato Tira-Manchas 1kg','Percarbonato Tira-Manchas 1kg para limpeza e uso domestico.','Roupas',29.90,94),(34,'Bicarbonato de Sodio 1kg','Bicarbonato de Sodio 1kg para limpeza e uso domestico.','Roupas',15.90,87),(35,'Limpa Pedras 5L','Limpa Pedras 5L para limpeza e uso domestico.','Pisos',44.90,51),(36,'Lava Azulejo e Pastilhas','Lava Azulejo e Pastilhas para limpeza e uso domestico.','Pisos',9.90,76),(37,'Pos Obra 5L','Pos Obra 5L para limpeza e uso domestico.','Pisos',54.90,34),(38,'UAU Essencia Concentrada 130ml','UAU Essencia Concentrada 130ml para limpeza e uso domestico.','Limpeza Geral',16.90,25),(39,'Limpador Multiuso 500ml','Limpador Multiuso 500ml para limpeza e uso domestico.','Limpeza Geral',4.99,15),(40,'Limpador Multiuso Perfumado UAU 500ml','Limpador Multiuso Perfumado UAU 500ml para limpeza e uso domestico.','Limpeza Geral',5.49,81),(41,'Limpador Perfumado UAU 500ml','Limpador Perfumado UAU 500ml para limpeza e uso domestico.','Limpeza Geral',4.99,77),(42,'Limpador Perfumado 1L','Limpador Perfumado 1L para limpeza e uso domestico.','Limpeza Geral',9.99,41),(43,'Odorizador','Odorizador para limpeza e uso domestico.','Limpeza Geral',12.00,57),(44,'Saponaceo','Saponaceo para limpeza e uso domestico.','Limpeza Geral',5.90,62),(45,'Querosene','Querosene para limpeza e uso domestico.','Limpeza Geral',20.00,36),(46,'Multiuso Cremoso Limpeza Profunda','Multiuso Cremoso Limpeza Profunda para limpeza e uso domestico.','Limpeza Geral',9.50,75),(47,'Lustra Moveis 200ml','Lustra Moveis 200ml para limpeza e uso domestico.','Limpeza Geral',10.90,77),(48,'Solutroppel 5L','Solutroppel 5L para limpeza e uso domestico.','Limpeza Geral',24.90,60),(49,'Alcool Gel 70','Alcool Gel 70 para limpeza e uso domestico.','Limpeza Geral',45.00,60),(50,'Saco para Lixo 100L','Saco para Lixo 100L para limpeza e uso domestico.','Limpeza Geral',7.00,20),(51,'Sacos para Lixo 15L','Sacos para Lixo 15L para limpeza e uso domestico.','Limpeza Geral',5.49,93),(52,'Sacos para Lixo 30L','Sacos para Lixo 30L para limpeza e uso domestico.','Limpeza Geral',6.49,32),(53,'Sacos para Lixo 50L','Sacos para Lixo 50L para limpeza e uso domestico.','Limpeza Geral',7.00,52),(54,'Balde 8L','Balde 8L para limpeza e uso domestico.','Limpeza Geral',10.00,63),(55,'Balde 20L','Balde 20L para limpeza e uso domestico.','Limpeza Geral',24.90,60),(56,'Balde com Alca de Ferro 16L','Balde com Alca de Ferro 16L para limpeza e uso domestico.','Limpeza Geral',16.00,99),(57,'Pa de Mao','Pa de Mao para limpeza e uso domestico.','Limpeza Geral',4.00,35),(58,'Vassoura Varre Facil Condor','Vassoura Varre Facil Condor para limpeza e uso domestico.','Limpeza Geral',16.50,48),(59,'Vassoura de Pelo Sintetico','Vassoura de Pelo Sintetico para limpeza e uso domestico.','Limpeza Geral',13.00,35),(60,'Vassoura Limpa Mania Varreleve','Vassoura Limpa Mania Varreleve para limpeza e uso domestico.','Limpeza Geral',13.20,21),(61,'Vassoura Multiuso Limpa Mania Suprema','Vassoura Multiuso Limpa Mania Suprema para limpeza e uso domestico.','Limpeza Geral',13.50,84),(62,'Vassoura Caipira de Piacava','Vassoura Caipira de Piacava para limpeza e uso domestico.','Limpeza Geral',22.00,73),(63,'Rodo Plastico 30cm C/Cabo','Rodo Plastico 30cm C/Cabo para limpeza e uso domestico.','Limpeza Geral',7.90,14),(64,'Rodo Plastico 40cm C/Cabo','Rodo Plastico 40cm C/Cabo para limpeza e uso domestico.','Limpeza Geral',8.90,23),(65,'Cabo de Vassoura/Rodo Reforcado','Cabo de Vassoura/Rodo Reforcado para limpeza e uso domestico.','Limpeza Geral',3.90,62),(66,'Mascara Descartavel','Mascara Descartavel para limpeza e uso domestico.','Limpeza Geral',6.00,52),(67,'Pilha Alcalina Panasonic AAA','Pilha Alcalina Panasonic AAA para limpeza e uso domestico.','Limpeza Geral',8.90,62),(68,'Pneu Pretinho 1L','Pneu Pretinho 1L para limpeza e uso domestico.','Limpeza Geral',15.90,53),(69,'Prendedor de Roupas - 12 un.','Prendedor de Roupas - 12 un. para limpeza e uso domestico.','Acessorios',3.00,70),(70,'Prendedor de Roupas - 36 un.','Prendedor de Roupas - 36 un. para limpeza e uso domestico.','Acessorios',2.00,90),(71,'Cesto de Roupas 60L','Cesto de Roupas 60L para limpeza e uso domestico.','Acessorios',39.90,49),(72,'Saca-lavada Branco','Saca-lavada Branco para limpeza e uso domestico.','Acessorios',8.00,55);
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos_backup`
--

DROP TABLE IF EXISTS `produtos_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos_backup` (
  `id` int NOT NULL DEFAULT '0',
  `nome` varchar(150) NOT NULL,
  `descricao` text,
  `categoria` varchar(100) DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `estoque` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos_backup`
--

LOCK TABLES `produtos_backup` WRITE;
/*!40000 ALTER TABLE `produtos_backup` DISABLE KEYS */;
INSERT INTO `produtos_backup` VALUES (1,'Detergente Neutro','Detergente liquido para limpeza diaria','Cozinha',2.99,50),(2,'├â┬ügua sanit├â┬íria 2L','├â┬ügua sanit├â┬íria para limpeza e desinfec├â┬º├â┬úo, embalagem de 2 litros','Limpeza Geral',5.50,20),(3,'Lava Lou├â┬ºas Neutro 5L',NULL,'Cozinha',24.90,0),(4,'Esponja para Lou├â┬ºa - 3un.',NULL,'Cozinha',3.99,0),(5,'Esponja de A├â┬ºo',NULL,'Cozinha',3.50,0),(6,'Esponja de Limpeza Pesada',NULL,'Cozinha',5.00,0),(7,'Limpador Desengordurante 500ml',NULL,'Cozinha',9.90,0),(8,'Limpa Alum├â┬¡nio 5L',NULL,'Cozinha',29.90,0),(9,'Limpa Alum├â┬¡nio 850ml',NULL,'Cozinha',9.90,0),(10,'Guardanapo 50 un.',NULL,'Cozinha',2.00,0),(11,'Desengordurante 500ml',NULL,'Cozinha',9.90,0),(12,'Diabo Verde',NULL,'Banheiro',23.00,0),(13,'Detergente Clorado',NULL,'Banheiro',32.00,0),(14,'Desinfetante UAU Antibact├â┬®rias 2L',NULL,'Banheiro',9.99,0),(15,'├â┬ügua Sanit├â┬íria 5L',NULL,'Banheiro',12.00,0),(16,'Hipoclorito de S├â┬│dio 5L',NULL,'Banheiro',34.00,0),(17,'Escova Sanit├â┬íria com Suporte',NULL,'Banheiro',12.00,0),(18,'Rodinho de Pia',NULL,'Banheiro',3.50,0),(19,'Sabonete L├â┬¡quido Pimenta Rosa',NULL,'Banheiro',12.90,0),(20,'Sabonete Flor de Laranjeira',NULL,'Banheiro',16.90,0),(21,'Sabonete L├â┬¡quido Bergamota Citrus',NULL,'Banheiro',14.90,0),(22,'Sabonete L├â┬¡quido ├â┬ügua de Coco',NULL,'Banheiro',14.90,0),(23,'Lava Roupas Uau 2.7L Perfumado Premium',NULL,'Roupas',32.00,0),(24,'Lava Roupas coco & vanilla 750ml',NULL,'Roupas',10.90,0),(25,'Lava Roupas Rosas ├â┬® Sedu├â┬º├â┬úo 3L',NULL,'Roupas',32.00,0),(26,'Lava Roupas L├â┬¡quido UAU Premium Coco & Vanilla 1,7L',NULL,'Roupas',19.90,0),(27,'Lava Roupas L├â┬¡quido UAU Active 1,7L',NULL,'Roupas',19.90,0),(28,'Lava Roupas L├â┬¡quido Clariel Care Clarilimp 5L',NULL,'Roupas',27.00,0),(29,'Lava Roupas Blue Care Clarilimp 5L',NULL,'Roupas',22.00,0),(30,'Lava Roupas L├â┬¡quido Coconut 5L',NULL,'Roupas',27.00,0),(31,'Lava Roupas Active 800ml',NULL,'Roupas',12.99,0),(32,'Amaciante Concentrado UAU 500ml',NULL,'Roupas',9.90,0),(33,'Percarbonato Tira-Manchas 1kg',NULL,'Roupas',29.90,0),(34,'Bicarbonato de S├â┬│dio 1kg',NULL,'Roupas',15.90,0),(35,'Limpa Pedras 5L',NULL,'Pisos',44.90,0),(36,'Lava Azulejo e Pastilhas',NULL,'Pisos',9.90,0),(37,'P├â┬│s Obra 5L',NULL,'Pisos',54.90,0),(38,'UAU Ess├â┬¬ncia Concentrada 130ml',NULL,'Limpeza Geral',16.90,0),(39,'Limpador Multiuso 500ml',NULL,'Limpeza Geral',4.99,0),(40,'Limpador Multiuso Perfumado UAU 500ml',NULL,'Limpeza Geral',5.49,0),(41,'Limpador Perfumado UAU 500ml',NULL,'Limpeza Geral',4.99,0),(42,'Limpador Perfumado 1L',NULL,'Limpeza Geral',9.99,0),(43,'Odorizador',NULL,'Limpeza Geral',12.00,0),(44,'Sapon├â┬íceo',NULL,'Limpeza Geral',5.90,0),(45,'Querosene',NULL,'Limpeza Geral',20.00,0),(46,'Multiuso Cremoso Limpeza Profunda',NULL,'Limpeza Geral',9.50,0),(47,'Lustra M├â┬│veis 200ml',NULL,'Limpeza Geral',10.90,0),(48,'Solutr├â┬│ppel 5L',NULL,'Limpeza Geral',24.90,0),(49,'├â┬ülcool Gel 70',NULL,'Limpeza Geral',45.00,0),(50,'Saco para Lixo 100L',NULL,'Limpeza Geral',7.00,0),(51,'Sacos para Lixo 15L',NULL,'Limpeza Geral',5.49,0),(52,'Sacos para Lixo 30L',NULL,'Limpeza Geral',6.49,0),(53,'Sacos para Lixo 50L',NULL,'Limpeza Geral',7.00,0),(54,'Balde 8L',NULL,'Limpeza Geral',10.00,0),(55,'Balde 20L',NULL,'Limpeza Geral',24.90,0),(56,'Balde com Al├â┬ºa de Ferro 16L',NULL,'Limpeza Geral',16.00,0),(57,'P├â┬í de M├â┬úo',NULL,'Limpeza Geral',4.00,0),(58,'Vassoura Varre F├â┬ícil Condor',NULL,'Limpeza Geral',16.50,0),(59,'Vassoura de Pelo Sint├â┬®tico',NULL,'Limpeza Geral',13.00,0),(60,'Vassoura Limpa Mania Varreleve',NULL,'Limpeza Geral',13.20,0),(61,'Vassoura Multiuso Limpa Mania Suprema',NULL,'Limpeza Geral',13.50,0),(62,'Vassoura Caipira de Pia├â┬ºava',NULL,'Limpeza Geral',22.00,0),(63,'Rodo Pl├â┬ístico 30cm C/Cabo',NULL,'Limpeza Geral',7.90,0),(64,'Rodo Pl├â┬ístico 40cm C/Cabo',NULL,'Limpeza Geral',8.90,0),(65,'Cabo de Vassoura/Rodo Refor├â┬ºado',NULL,'Limpeza Geral',3.90,0),(66,'M├â┬íscara Descart├â┬ível',NULL,'Limpeza Geral',6.00,0),(67,'Pilha Alcalina Panasonic AAA',NULL,'Limpeza Geral',8.90,0),(68,'Pneu Pretinho 1L',NULL,'Limpeza Geral',15.90,0),(69,'Prendedor de Roupas ├óÔé¼ÔÇ£ 12 un.',NULL,'Acess├â┬│rios',3.00,0),(70,'Prendedor de Roupas ├óÔé¼ÔÇ£ 36 un.',NULL,'Acess├â┬│rios',2.00,0),(71,'Cesto de Roupas 60L',NULL,'Acess├â┬│rios',39.90,0),(72,'Saca-lavada Branco',NULL,'Acess├â┬│rios',8.00,0);
/*!40000 ALTER TABLE `produtos_backup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-05 23:04:56
