-- ============================================================
-- LIMPEZA TOTAL - Scripts do banco (juntados das abas antigas)
-- Rode cada bloco conforme a necessidade. Todos sao seguros
-- de rodar mais de uma vez (IF NOT EXISTS / UPDATE).
-- ============================================================

USE limpeza_total;

-- ------------------------------------------------------------
-- 1) TABELA DE USUARIOS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(150) NOT NULL,
    usuario VARCHAR(80) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,   -- guardar HASH (bcrypt), nunca a senha pura
    tipo ENUM('dono', 'funcionario') NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2) TABELA DE MOVIMENTACOES DE ESTOQUE
--    (precisa de produtos e usuarios ja criadas)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS movimentacoes_estoque (
    id INT NOT NULL AUTO_INCREMENT,
    produto_id INT NOT NULL,
    tipo ENUM('entrada', 'saida', 'ajuste') NOT NULL,
    quantidade INT NOT NULL,
    observacao TEXT NULL,
    usuario_id INT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_mov_produto
        FOREIGN KEY (produto_id) REFERENCES produtos(id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_mov_usuario
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3) USUARIO DA API (rodar como root)
--    Troque TROQUE_AQUI por uma senha sua e use a mesma na API.
-- ------------------------------------------------------------
-- ALTER USER 'limpeza_app'@'localhost' IDENTIFIED BY 'TROQUE_AQUI';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON limpeza_total.* TO 'limpeza_app'@'localhost';
-- FLUSH PRIVILEGES;

-- ------------------------------------------------------------
-- 4) IMAGENS DOS PRODUTOS (coluna imagem precisa existir)
--    Se nao existir: ALTER TABLE produtos ADD COLUMN imagem VARCHAR(255) NULL;
--    ATENCAO: renomeie estes arquivos (acento/virgula quebram em servidor):
--      id 25 -> rosaseseduçao.jpeg   id 27 -> LRACTIVE1,7.jpeg
--    Sem imagem neste script: ids 1, 7, 11, 26, 42 e 72.
-- ------------------------------------------------------------
UPDATE produtos
SET imagem = CASE id
    WHEN 2 THEN '/imagens/agua2l.jpeg'
    WHEN 3 THEN '/imagens/lavaloucaneutro.jpeg'
    WHEN 4 THEN '/imagens/esponjaparalouca.jpeg'
    WHEN 5 THEN '/imagens/esponjaaco.jpeg'
    WHEN 6 THEN '/imagens/esponjaLP.jpeg'
    WHEN 8 THEN '/imagens/limpaaluminio5l.jpeg'
    WHEN 9 THEN '/imagens/limpaaluminio850ml.jpeg'
    WHEN 10 THEN '/imagens/guardanapo.jpeg'
    WHEN 12 THEN '/imagens/diaboverde.jpeg'
    WHEN 13 THEN '/imagens/detergenteclorado.jpeg'
    WHEN 14 THEN '/imagens/desinfetanteantibac.jpeg'
    WHEN 15 THEN '/imagens/agua5l.jpeg'
    WHEN 16 THEN '/imagens/hipoclorito.jpeg'
    WHEN 17 THEN '/imagens/escovabanheiro.jpeg'
    WHEN 18 THEN '/imagens/rodopia.jpeg'
    WHEN 19 THEN '/imagens/pimentarosa.jpeg'
    WHEN 20 THEN '/imagens/flordelaranjeira.jpeg'
    WHEN 21 THEN '/imagens/bergamota.jpeg'
    WHEN 22 THEN '/imagens/aguadecoco.jpeg'
    WHEN 23 THEN '/imagens/lavaroupaspremium.jpeg'
    WHEN 24 THEN '/imagens/cocoevanilla750ml.jpeg'
    WHEN 25 THEN '/imagens/rosaseseduçao.jpeg'
    WHEN 27 THEN '/imagens/LRACTIVE1,7.jpeg'
    WHEN 28 THEN '/imagens/LVclarielcare.jpeg'
    WHEN 29 THEN '/imagens/LVbluecare.jpeg'
    WHEN 30 THEN '/imagens/LRcoconut.jpeg'
    WHEN 31 THEN '/imagens/active800ml.jpeg'
    WHEN 32 THEN '/imagens/amaciante500ml.jpeg'
    WHEN 33 THEN '/imagens/tiramanchas.jpeg'
    WHEN 34 THEN '/imagens/bicabornato.jpeg'
    WHEN 35 THEN '/imagens/limpapedras.jpeg'
    WHEN 36 THEN '/imagens/lavaazulejo.jpeg'
    WHEN 37 THEN '/imagens/posobra.jpeg'
    WHEN 38 THEN '/imagens/essencia.jpeg'
    WHEN 39 THEN '/imagens/multiuso500.jpeg'
    WHEN 40 THEN '/imagens/limpadoruauvermelho.jpeg'
    WHEN 41 THEN '/imagens/limpadorperfumadouau.jpeg'
    WHEN 43 THEN '/imagens/odorizador.jpeg'
    WHEN 44 THEN '/imagens/saponaceo.jpeg'
    WHEN 45 THEN '/imagens/querosene.jpeg'
    WHEN 46 THEN '/imagens/multiusocremoso.jpeg'
    WHEN 47 THEN '/imagens/lustramoveisuau.jpeg'
    WHEN 48 THEN '/imagens/solutroppel.jpeg'
    WHEN 49 THEN '/imagens/alcoolgel70.jpeg'
    WHEN 50 THEN '/imagens/lixo100l.jpeg'
    WHEN 51 THEN '/imagens/lixo15l.jpeg'
    WHEN 52 THEN '/imagens/lixo30l.jpeg'
    WHEN 53 THEN '/imagens/lixo50l.jpeg'
    WHEN 54 THEN '/imagens/balde8l.jpeg'
    WHEN 55 THEN '/imagens/balde20l.jpeg'
    WHEN 56 THEN '/imagens/baldeferro.jpeg'
    WHEN 57 THEN '/imagens/pademao.jpeg'
    WHEN 58 THEN '/imagens/vassouracondor.jpeg'
    WHEN 59 THEN '/imagens/vassourapelosintetico.jpeg'
    WHEN 60 THEN '/imagens/varreleve.jpeg'
    WHEN 61 THEN '/imagens/vassmulti.jpeg'
    WHEN 62 THEN '/imagens/vasscaipira.jpeg'
    WHEN 63 THEN '/imagens/rodo30.jpeg'
    WHEN 64 THEN '/imagens/rodo40.jpeg'
    WHEN 65 THEN '/imagens/cabosdiversos.jpeg'
    WHEN 66 THEN '/imagens/mascara.jpeg'
    WHEN 67 THEN '/imagens/pilhapana.jpeg'
    WHEN 68 THEN '/imagens/pneupretinho.jpeg'
    WHEN 69 THEN '/imagens/prendedor12.jpeg'
    WHEN 70 THEN '/imagens/prendedor36.jpeg'
    WHEN 71 THEN '/imagens/cestoroupa.jpeg'
    ELSE imagem
END
WHERE id BETWEEN 1 AND 72;

-- ------------------------------------------------------------
-- 5) CONSULTAS UTEIS (so leitura)
-- ------------------------------------------------------------
-- SHOW TABLES;
-- SELECT COUNT(*) AS total FROM produtos;
-- DESCRIBE produtos;
-- DESCRIBE usuarios;
-- DESCRIBE movimentacoes_estoque;
-- SELECT id, nome, imagem FROM produtos ORDER BY id;
