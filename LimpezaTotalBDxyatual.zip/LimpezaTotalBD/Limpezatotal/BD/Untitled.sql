USE limpeza_total;

SHOW TABLES;