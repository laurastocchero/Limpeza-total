USE limpeza_total;
SHOW CREATE TABLE produtos;
