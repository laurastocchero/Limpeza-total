ALTER USER 'limpeza_app'@'localhost'
IDENTIFIED BY 'NovaSenha@2026';

GRANT ALL PRIVILEGES ON limpeza_total.*
TO 'limpeza_app'@'localhost';