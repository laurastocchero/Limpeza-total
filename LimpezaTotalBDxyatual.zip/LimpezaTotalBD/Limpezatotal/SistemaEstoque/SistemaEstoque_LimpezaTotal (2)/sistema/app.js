
(function () {
"use strict";

/* ==================================================
   LIMPEZA TOTAL — APLICAÇÃO
   Integração com API Node.js + MySQL
================================================== */

var API = "http://localhost:3000/api";
var TOKEN = sessionStorage.getItem("limpezaToken") || "";
var USUARIO = JSON.parse(sessionStorage.getItem("limpezaUsuario") || "{}");

var E = {
    produtos: [],
    movs: [],
    despesas: [],
    categorias: [],
    loja: "Limpeza Total"
};

var VIEW = "painel";
var F = { q: "", cat: "", sit: "", modo: "todos" };
var FM = { q: "", tipo: "", ini: "", fim: "" };
var PER = { tipo: "30", ini: "", fim: "" };
var itensVenda = [];
var entradaSel = null;
var modalOk = null;
var imgTemp = "";
var iniciou = false;

var $ = function (s) {
    return document.querySelector(s);
};

var $$ = function (s) {
    return Array.from(document.querySelectorAll(s));
};

var R = function (v) {
    return Number(v || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
};

var N = function (v) {
    return Number(v || 0).toLocaleString("pt-BR");
};

var num = function (v) {
    return Number(String(v || "").replace(",", ".")) || 0;
};

var esc = function (s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        }[c];
    });
};

var norm = function (s) {
    return String(s || "").normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
};

var hoje = function () {
    var d = new Date();
    return d.getFullYear() + "-" +
        String(d.getMonth() + 1).padStart(2, "0") + "-" +
        String(d.getDate()).padStart(2, "0");
};

var uid = function () {
    return Date.now().toString(36) +
        Math.random().toString(36).slice(2, 8);
};

var fmtData = function (d) {
    if (!d) return "—";
    var s = String(d).slice(0, 10);
    var p = s.split("-");
    return p.length === 3 ? p[2] + "/" + p[1] + "/" + p[0] : s;
};

function aviso(msg, erro) {
    var t = $("#toast");
    if (!t) {
        alert(msg);
        return;
    }
    t.textContent = msg;
    t.className = "toast" + (erro ? " erro" : "");
    t.hidden = false;
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(function () {
        t.hidden = true;
    }, 3500);
}

/* ==================================================
   API
================================================== */

async function requisicaoAPI(rota, metodo, dados) {
    var cab = {
        "Content-Type": "application/json"
    };

    if (TOKEN) cab.Authorization = "Bearer " + TOKEN;

    var resposta = await fetch(API + rota, {
        method: metodo || "GET",
        headers: cab,
        body: dados === undefined ? undefined : JSON.stringify(dados)
    });

    var resultado = {};
    var texto = await resposta.text();

    try {
        resultado = texto ? JSON.parse(texto) : {};
    } catch (e) {
        resultado = {};
    }

    if (!resposta.ok) {
        if (resposta.status === 401 && TOKEN) {
            TOKEN = "";
            sessionStorage.removeItem("limpezaToken");
            sessionStorage.removeItem("limpezaUsuario");
            iniciou = false;
            telaLogin();
        }
        throw new Error(resultado.erro || resultado.mensagem ||
            "Erro na comunicação com o servidor.");
    }

    return resultado;
}

function interpretarObservacao(obs) {
    var r = {};
    String(obs || "").split("|").forEach(function (parte) {
        var i = parte.indexOf("=");
        if (i < 0) return;
        var chave = parte.slice(0, i).trim().toUpperCase();
        var valor = parte.slice(i + 1).trim();
        r[chave] = valor;
    });
    return r;
}

function converterMovimento(m) {
    var meta = interpretarObservacao(m.observacao);
    var tipo = m.tipo;
    var qtd = Number(m.quantidade || 0);
    var delta = tipo === "saida" ? -qtd : qtd;

    var especial = String(m.observacao || "").toUpperCase();

    if (especial.indexOf("[VENDA]") >= 0) tipo = "venda";
    else if (especial.indexOf("[PERDA]") >= 0) tipo = "perda";
    else if (especial.indexOf("[AJUSTE]") >= 0) tipo = "ajuste";

    if (tipo === "ajuste") delta = qtd;

    return {
        id: m.id,
        produtoId: m.produto_id,
        nome: m.produto || "Produto",
        tipo: tipo,
        qtd: Math.abs(qtd),
        delta: delta,
        data: m.criado_em ? String(m.criado_em).slice(0, 10) : hoje(),
        ts: m.criado_em ? new Date(m.criado_em).getTime() : 0,
        custo: num(meta.CUSTO),
        preco: num(meta.PRECO),
        cliente: meta.CLIENTE || "",
        pagamento: meta.PAGAMENTO || "",
        pago: meta.PAGO !== "NAO",
        fornecedor: meta.FORNECEDOR || "",
        motivo: meta.MOTIVO || "",
        obs: m.observacao || "",
        usuario: m.usuario || ""
    };
}

async function carregarDadosAPI() {
    var respostas = await Promise.all([
        requisicaoAPI("/produtos"),
        requisicaoAPI("/estoque/movimentacoes")
    ]);

    var locais = {};
    try {
        locais = JSON.parse(localStorage.getItem("limpezaCustos") || "{}");
    } catch (e) {}

    E.produtos = respostas[0].map(function (p) {
        var local = locais[p.id] || {};
        return {
            id: p.id,
            nome: p.nome,
            descricao: p.descricao || "",
            categoria: p.categoria || "Sem categoria",
            preco: Number(p.preco || 0),
            estoque: Number(p.estoque || 0),
            imagem: p.imagem || "",
            custo: Number(local.custo || 0),
            minimo: Number(local.minimo || 0),
            unidade: local.unidade || "un",
            codigo: local.codigo || "",
            ativo: true
        };
    });

    E.movs = respostas[1].map(converterMovimento);

    E.categorias = Array.from(new Set(
        E.produtos.map(function (p) { return p.categoria; })
    )).filter(Boolean).sort();

    salvarCustos();
}

function salvarCustos() {
    var dados = {};
    E.produtos.forEach(function (p) {
        dados[p.id] = {
            custo: p.custo || 0,
            minimo: p.minimo || 0,
            unidade: p.unidade || "un",
            codigo: p.codigo || ""
        };
    });
    localStorage.setItem("limpezaCustos", JSON.stringify(dados));
}

function salvar() {
    salvarCustos();
    salvarLocal();
}

function salvarLocal() {
    localStorage.setItem("limpezaConfiguracoes", JSON.stringify({
        loja: E.loja,
        despesas: E.despesas,
        categorias: E.categorias
    }));
}

function carregarLocal() {
    try {
        var d = JSON.parse(localStorage.getItem("limpezaConfiguracoes") || "{}");
        E.loja = d.loja || "Limpeza Total";
        E.despesas = d.despesas || [];
        E.categorias = d.categorias || [];
    } catch (e) {}
}

function ativos() {
    return E.produtos.filter(function (p) {
        return p.ativo !== false;
    });
}

function prod(id) {
    return E.produtos.find(function (p) {
        return String(p.id) === String(id);
    });
}

function achaProduto(nome) {
    var n = norm(nome);
    return ativos().find(function (p) {
        return norm(p.nome) === n;
    });
}

/* ==================================================
   NAVEGAÇÃO E RENDERIZAÇÃO
================================================== */

function titulo(t, subtitulo) {
    return "<div class=\"topo-pagina\"><h1>" + esc(t) +
        "</h1><p class=\"mm\">" + esc(subtitulo || "") +
        "</p></div>";
}

function irPara(v) {
    VIEW = v || "painel";
    location.hash = VIEW;
    render();
}

function render() {
    if (!TOKEN) {
        telaLogin();
        return;
    }

    VIEW = location.hash.replace("#", "") || "painel";

    var funcoes = {
        painel: vPainel,
        produtos: vProdutos,
        entrada: vEntrada,
        venda: vVenda,
        movimentos: vMovimentos,
        financeiro: vFinanceiro,
        config: vConfig
    };

    if (!funcoes[VIEW]) VIEW = "painel";

    $$("#menu a").forEach(function (a) {
        a.classList.toggle("ativo", a.dataset.v === VIEW);
    });

    funcoes[VIEW]();
}

/* ==================================================
   PAINEL
================================================== */

function kpi(nome, valor, detalhe, classe) {
    return "<div class=\"kpi " + (classe || "") + "\">" +
        "<span>" + nome + "</span><strong>" + valor +
        "</strong><small>" + (detalhe || "") + "</small></div>";
}

function resumo(inicio, fim) {
    var r = {
        receita: 0, cmv: 0, bruto: 0, perdas: 0,
        compras: 0, despesas: 0, nVendas: 0, itens: 0,
        margem: 0, liquido: 0
    };

    E.movs.forEach(function (m) {
        if (m.data < inicio || m.data > fim) return;

        if (m.tipo === "venda") {
            r.receita += m.qtd * m.preco;
            r.cmv += m.qtd * m.custo;
            r.nVendas++;
            r.itens += m.qtd;
        }

        if (m.tipo === "perda") {
            r.perdas += m.qtd * m.custo;
        }

        if (m.tipo === "entrada") {
            var meta = interpretarObservacao(m.obs);
            r.compras += m.qtd * num(meta.CUSTO);
        }
    });

    E.despesas.forEach(function (d) {
        if (d.data >= inicio && d.data <= fim) r.despesas += d.valor;
    });

    r.bruto = r.receita - r.cmv;
    r.liquido = r.bruto - r.perdas - r.despesas;
    r.margem = r.receita ? r.bruto / r.receita * 100 : 0;

    return r;
}

function vPainel() {
    var inicio = hoje().slice(0, 8) + "01";
    var r = resumo(inicio, hoje());
    var estoque = ativos().reduce(function (a, p) {
        return a + p.estoque;
    }, 0);
    var baixo = ativos().filter(function (p) {
        return p.estoque <= p.minimo;
    });

    var html = titulo("Painel", "Visão geral da " + E.loja);

    html += "<div class=\"kpis\">" +
        kpi("Produtos cadastrados", N(ativos().length), "Produtos ativos", "") +
        kpi("Unidades em estoque", N(estoque), "Quantidade total", "roxo") +
        kpi("Vendas do mês", R(r.receita), r.nVendas + " venda(s)", "pos") +
        kpi("Lucro bruto", R(r.bruto), "Margem " + r.margem.toFixed(1) + "%", "") +
        "</div>";

    html += "<h2 class=\"sec\">Atenção ao estoque</h2>";

    html += baixo.length
        ? "<div class=\"rolar\"><table><tr><th>Produto</th><th>Estoque</th><th>Mínimo</th></tr>" +
          baixo.map(function (p) {
              return "<tr><td>" + esc(p.nome) + "</td><td class=\"neg\">" +
                  N(p.estoque) + "</td><td>" + N(p.minimo) + "</td></tr>";
          }).join("") + "</table></div>"
        : "<p class=\"vazio\">Todos os produtos estão com estoque adequado.</p>";

    html += "<h2 class=\"sec\">Movimentações recentes</h2>" +
        tabelaMovs(E.movs.slice().sort(function (a, b) {
            return b.ts - a.ts;
        }).slice(0, 10), false);

    $("#app").innerHTML = html;
}

/* ==================================================
   PRODUTOS
================================================== */

function listaProdutos() {
    var el = $("#p-lista");
    if (!el) return;

    var q = norm(F.q);
    var lista = ativos().filter(function (p) {
        if (q && !norm(p.nome + " " + p.categoria + " " + p.codigo).includes(q))
            return false;
        if (F.cat && p.categoria !== F.cat) return false;
        if (F.sit === "baixo" && p.estoque > p.minimo) return false;
        if (F.sit === "zerado" && p.estoque > 0) return false;
        return true;
    });

    el.innerHTML = lista.length
        ? "<div class=\"rolar\"><table><tr><th>Produto</th><th>Categoria</th><th>Preço</th><th>Estoque</th><th></th></tr>" +
          lista.map(function (p) {
              return "<tr><td><b>" + esc(p.nome) + "</b><br><small>" +
                  esc(p.descricao) + "</small></td><td>" + esc(p.categoria) +
                  "</td><td>" + R(p.preco) + "</td><td>" +
                  (p.estoque <= p.minimo ? "<span class=\"neg\">" : "") +
                  N(p.estoque) + " " + esc(p.unidade) +
                  (p.estoque <= p.minimo ? "</span>" : "") +
                  "</td><td><button class=\"btn peq\" data-acao=\"editar\" data-id=\"" +
                  esc(p.id) + "\">Editar</button> " +
                  "<button class=\"btn peq verm\" data-acao=\"excluir-prod\" data-id=\"" +
                  esc(p.id) + "\">Arquivar</button></td></tr>";
          }).join("") + "</table></div>"
        : "<p class=\"vazio\">Nenhum produto encontrado.</p>";
}

function vProdutos() {
    var html = titulo("Produtos", "Consulte e gerencie seus produtos");

    html += "<div class=\"acoes\"><button class=\"btn\" data-acao=\"novo-produto\">+ Novo produto</button>" +
        "<button class=\"btn sec\" data-acao=\"csv-produtos\">Exportar CSV</button></div>";

    html += "<div class=\"filtros\">" +
        "<input id=\"f-q\" placeholder=\"Buscar produto...\" value=\"" + esc(F.q) + "\">" +
        "<select id=\"f-cat\"><option value=\"\">Todas as categorias</option>" +
        E.categorias.map(function (c) {
            return "<option " + (F.cat === c ? "selected" : "") + ">" +
                esc(c) + "</option>";
        }).join("") + "</select>" +
        "<select id=\"f-sit\"><option value=\"\">Todos os estoques</option>" +
        "<option value=\"baixo\" " + (F.sit === "baixo" ? "selected" : "") +
        ">Estoque baixo</option><option value=\"zerado\" " +
        (F.sit === "zerado" ? "selected" : "") + ">Zerado</option></select></div>";

    html += "<div id=\"p-lista\"></div>";
    $("#app").innerHTML = html;
    listaProdutos();
}

function abrirProduto(id) {
    var p = id ? prod(id) : null;
    imgTemp = p ? p.imagem : "";

    var html = "<div class=\"linha\"><div class=\"campo\">" +
        "<label>Nome *</label><input id=\"p-nome\" value=\"" +
        esc(p ? p.nome : "") + "\"></div>" +
        "<div class=\"campo\"><label>Categoria</label><input id=\"p-cat\" list=\"p-cats\" value=\"" +
        esc(p ? p.categoria : "") + "\"><datalist id=\"p-cats\">" +
        E.categorias.map(function (c) {
            return "<option value=\"" + esc(c) + "\">";
        }).join("") + "</datalist></div></div>" +
        "<div class=\"campo\"><label>Descrição</label><textarea id=\"p-desc\">" +
        esc(p ? p.descricao : "") + "</textarea></div>" +
        "<div class=\"linha\"><div class=\"campo\"><label>Preço de venda *</label>" +
        "<input id=\"p-preco\" type=\"number\" min=\"0\" step=\"0.01\" value=\"" +
        (p ? p.preco : "") + "\"></div>" +
        "<div class=\"campo\"><label>Custo unitário (local)</label>" +
        "<input id=\"p-custo\" type=\"number\" min=\"0\" step=\"0.01\" value=\"" +
        (p ? p.custo : "") + "\"></div></div>" +
        "<div class=\"linha\"><div class=\"campo\"><label>Estoque mínimo (local)</label>" +
        "<input id=\"p-min\" type=\"number\" min=\"0\" value=\"" +
        (p ? p.minimo : 0) + "\"></div>" +
        "<div class=\"campo\"><label>Unidade</label><input id=\"p-un\" value=\"" +
        esc(p ? p.unidade : "un") + "\"></div></div>" +
        "<div class=\"campo\"><label>Imagem (opcional)</label><input id=\"p-img\" type=\"file\" accept=\"image/*\">" +
        "<div id=\"prev-img\">" + (imgTemp ? "<img src=\"" + esc(imgTemp) + "\">" : "") +
        "</div></div>";

    abrirModal(p ? "Editar produto" : "Novo produto", html, "Salvar", async function () {
        var nome = $("#p-nome").value.trim();
        var preco = $("#p-preco").value;

        if (!nome || preco === "" || num(preco) < 0) {
            aviso("Informe nome e preço válido.", true);
            return false;
        }

        var dados = {
            nome: nome,
            descricao: $("#p-desc").value.trim(),
            categoria: $("#p-cat").value.trim() || null,
            preco: num(preco),
            imagem: imgTemp || null
        };

        try {
            if (p) {
                await requisicaoAPI("/produtos/" + p.id, "PUT", dados);
                p.custo = num($("#p-custo").value);
                p.minimo = num($("#p-min").value);
                p.unidade = $("#p-un").value.trim() || "un";
            } else {
                await requisicaoAPI("/produtos", "POST", Object.assign({}, dados, {
                    estoque: 0
                }));
            }

            if (dados.categoria && E.categorias.indexOf(dados.categoria) < 0)
                E.categorias.push(dados.categoria);

            await carregarDadosAPI();
            salvar();
            fecharModal();
            render();
            aviso("Produto salvo.");
            return true;
        } catch (e) {
            aviso(e.message, true);
            return false;
        }
    });
}

/* ==================================================
   IMAGENS
================================================== */

function lerImagem(file) {
    return new Promise(function (resolve, reject) {
        if (!file.type.startsWith("image/")) {
            reject(new Error("Arquivo inválido."));
            return;
        }

        var reader = new FileReader();
        reader.onload = function () { resolve(reader.result); };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function atualizaMargem() {}

/* ==================================================
   ENTRADAS
================================================== */

function opcoesProdutos() {
    return "<datalist id=\"dl-prod\">" +
        ativos().map(function (p) {
            return "<option value=\"" + esc(p.nome) + "\">";
        }).join("") + "</datalist>";
}

function vEntrada() {
    $("#app").innerHTML = titulo("Entrada de estoque", "Registre compras e reposições") +
        opcoesProdutos() +
        "<div class=\"form\"><div class=\"campo\"><label>Produto</label>" +
        "<input id=\"e-prod\" list=\"dl-prod\"></div><div id=\"e-info\" class=\"info\" hidden></div>" +
        "<div class=\"linha\"><div class=\"campo\"><label>Quantidade</label><input id=\"e-qtd\" type=\"number\" min=\"1\"></div>" +
        "<div class=\"campo\"><label>Custo unitário</label><input id=\"e-custo\" type=\"number\" min=\"0\" step=\"0.01\"></div>" +
        "<div class=\"campo\"><label>Novo preço de venda</label><input id=\"e-preco\" type=\"number\" min=\"0\" step=\"0.01\"></div></div>" +
        "<div class=\"linha\"><div class=\"campo\"><label>Fornecedor</label><input id=\"e-forn\"></div>" +
        "<div class=\"campo\"><label>Observação</label><input id=\"e-obs\"></div></div>" +
        "<div class=\"total-box\"><span>Total</span><b id=\"e-total\">R$ 0,00</b></div>" +
        "<button class=\"btn\" data-acao=\"salvar-entrada\">Registrar entrada</button></div>" +
        "<h2 class=\"sec\">Últimas entradas</h2>" +
        tabelaMovs(E.movs.filter(function (m) {
            return m.tipo === "entrada";
        }).slice(0, 10), false);

    entradaSel = null;
}

function entradaSelecionar(p) {
    entradaSel = p;
    var i = $("#e-info");
    if (!i) return;
    if (!p) {
        i.hidden = true;
        return;
    }
    i.hidden = false;
    i.innerHTML = "Estoque atual: <b>" + N(p.estoque) +
        "</b> • Preço: <b>" + R(p.preco) + "</b>";
    $("#e-custo").value = p.custo || "";
}

function totalEntrada() {
    var el = $("#e-total");
    if (el) el.textContent = R(num($("#e-qtd").value) * num($("#e-custo").value));
}

async function salvarEntrada() {
    var p = entradaSel || achaProduto($("#e-prod").value);
    var q = Math.floor(num($("#e-qtd").value));
    var c = num($("#e-custo").value);

    if (!p) return aviso("Escolha um produto.", true);
    if (q <= 0 || $("#e-custo").value === "")
        return aviso("Informe quantidade e custo.", true);

    var obs = "[ENTRADA] CUSTO=" + c.toFixed(2) +
        " | FORNECEDOR=" + $("#e-forn").value.trim() +
        " | " + $("#e-obs").value.trim();

    try {
        await requisicaoAPI("/estoque/movimentacoes", "POST", {
            produto_id: Number(p.id),
            tipo: "entrada",
            quantidade: q,
            observacao: obs
        });

        var antigo = p.estoque * (p.custo || 0);
        p.custo = (antigo + q * c) / (p.estoque + q);

        if ($("#e-preco").value !== "") {
            await requisicaoAPI("/produtos/" + p.id, "PUT", {
                nome: p.nome,
                descricao: p.descricao,
                categoria: p.categoria,
                preco: num($("#e-preco").value),
                imagem: p.imagem
            });
        }

        await carregarDadosAPI();
        salvar();
        aviso("Entrada registrada.");
        render();
    } catch (e) {
        await carregarDadosAPI().catch(function () {});
        aviso(e.message, true);
    }
}

/* ==================================================
   VENDAS
================================================== */

function vVenda() {
    $("#app").innerHTML = titulo("Nova venda", "Registre uma venda") +
        opcoesProdutos() +
        "<div class=\"form\"><div class=\"linha\"><div class=\"campo\"><label>Produto</label>" +
        "<input id=\"v-prod\" list=\"dl-prod\"></div><div class=\"campo\"><label>Quantidade</label>" +
        "<input id=\"v-qtd\" type=\"number\" min=\"1\" value=\"1\"></div>" +
        "<div class=\"campo\"><label>Preço unitário</label><input id=\"v-preco\" type=\"number\" step=\"0.01\"></div></div>" +
        "<div id=\"v-info\" class=\"info\" hidden></div>" +
        "<button class=\"btn roxo\" data-acao=\"add-item\">Adicionar produto</button>" +
        "<div id=\"v-itens\"></div><div class=\"linha\"><div class=\"campo\"><label>Cliente</label><input id=\"v-cli\"></div>" +
        "<div class=\"campo\"><label>Pagamento</label><select id=\"v-pag\"><option>Dinheiro</option><option>Pix</option>" +
        "<option>Cartão de débito</option><option>Cartão de crédito</option><option>Fiado (a receber)</option></select></div>" +
        "<div class=\"campo\"><label>Desconto</label><input id=\"v-desc\" type=\"number\" min=\"0\" value=\"0\"></div></div>" +
        "<div class=\"campo\"><label>Observação</label><input id=\"v-obs\"></div>" +
        "<div class=\"total-box\"><span>Total da venda</span><b id=\"v-total\">R$ 0,00</b></div>" +
        "<button class=\"btn\" data-acao=\"fechar-venda\">Finalizar venda</button></div>";

    desenhaItens();
}

function desenhaItens() {
    var el = $("#v-itens");
    if (!el) return;

    var sub = itensVenda.reduce(function (a, i) {
        return a + i.qtd * i.preco;
    }, 0);

    el.innerHTML = itensVenda.length
        ? "<div class=\"rolar\"><table><tr><th>Produto</th><th>Qtd.</th><th>Preço</th><th>Subtotal</th><th></th></tr>" +
          itensVenda.map(function (i, k) {
              return "<tr><td>" + esc(i.nome) + "</td><td>" + N(i.qtd) +
                  "</td><td>" + R(i.preco) + "</td><td>" + R(i.qtd * i.preco) +
                  "</td><td><button class=\"btn peq verm\" data-acao=\"rm-item\" data-k=\"" +
                  k + "\">Remover</button></td></tr>";
          }).join("") + "</table></div>"
        : "<p class=\"vazio\">Nenhum produto adicionado.</p>";

    totalVenda(sub);
}

function totalVenda(sub) {
    if (sub == null) {
        sub = itensVenda.reduce(function (a, i) {
            return a + i.qtd * i.preco;
        }, 0);
    }
    var t = $("#v-total");
    if (t) t.textContent = R(Math.max(0, sub - num($("#v-desc") && $("#v-desc").value)));
}

function qtdNoCarrinho(id) {
    return itensVenda.filter(function (i) {
        return String(i.id) === String(id);
    }).reduce(function (a, i) { return a + i.qtd; }, 0);
}

function addItem() {
    var p = achaProduto($("#v-prod").value);
    var q = Math.floor(num($("#v-qtd").value));
    var preco = num($("#v-preco").value);

    if (!p) return aviso("Escolha um produto.", true);
    if (q <= 0) return aviso("Informe a quantidade.", true);
    if (q + qtdNoCarrinho(p.id) > p.estoque)
        return aviso("Estoque insuficiente.", true);

    itensVenda.push({
        id: p.id,
        nome: p.nome,
        qtd: q,
        preco: preco || p.preco
    });

    $("#v-prod").value = "";
    $("#v-qtd").value = 1;
    $("#v-preco").value = "";
    desenhaItens();
}

async function fecharVenda() {
    if (!itensVenda.length) return aviso("Adicione produtos à venda.", true);

    var sub = itensVenda.reduce(function (a, i) {
        return a + i.qtd * i.preco;
    }, 0);

    var desconto = Math.min(num($("#v-desc").value), sub);
    var fator = sub ? (sub - desconto) / sub : 1;
    var pagamento = $("#v-pag").value;
    var cliente = $("#v-cli").value.trim();
    var obsGeral = $("#v-obs").value.trim();
    var idVenda = uid();

    for (var i = 0; i < itensVenda.length; i++) {
        var item = itensVenda[i];
        var p = prod(item.id);

        if (!p || item.qtd > p.estoque) {
            return aviso("Estoque insuficiente para " + item.nome, true);
        }
    }

    try {
        for (var j = 0; j < itensVenda.length; j++) {
            var itemAtual = itensVenda[j];
            var produto = prod(itemAtual.id);

            var obs = "[VENDA] PRECO=" +
                (itemAtual.preco * fator).toFixed(2) +
                " | CUSTO=" + Number(produto.custo || 0).toFixed(2) +
                " | CLIENTE=" + cliente +
                " | PAGAMENTO=" + pagamento +
                " | PAGO=" + (pagamento.indexOf("Fiado") === 0 ? "NAO" : "SIM") +
                " | " + obsGeral + " | Venda " + idVenda;

            await requisicaoAPI("/estoque/movimentacoes", "POST", {
                produto_id: Number(produto.id),
                tipo: "saida",
                quantidade: itemAtual.qtd,
                observacao: obs
            });
        }

        itensVenda = [];
        await carregarDadosAPI();
        aviso("Venda registrada com sucesso: " + R(sub - desconto));
        render();

    } catch (e) {
        await carregarDadosAPI().catch(function () {});
        aviso(e.message + " Verifique o estoque e o histórico antes de tentar novamente.", true);
    }
}

/* ==================================================
   MOVIMENTAÇÕES
================================================== */

var NOMES = {
    entrada: "Entrada",
    venda: "Venda",
    perda: "Perda",
    ajuste: "Ajuste"
};

function tabelaMovs(lista, acoes) {
    if (!lista.length) return "<p class=\"vazio\">Nenhuma movimentação.</p>";

    return "<div class=\"rolar\"><table><tr><th>Data</th><th>Tipo</th>" +
        "<th>Produto</th><th>Qtd.</th><th>Detalhes</th></tr>" +
        lista.map(function (m) {
            return "<tr><td>" + fmtData(m.data) + "</td><td>" +
                esc(NOMES[m.tipo] || m.tipo) + "</td><td>" +
                esc(m.nome) + "</td><td>" +
                (m.delta > 0 ? "+" : "") + N(m.delta) +
                "</td><td>" + esc(m.obs) + "</td></tr>";
        }).join("") + "</table></div>";
}

function movsFiltrados() {
    var q = norm(FM.q);

    return E.movs.filter(function (m) {
        if (FM.tipo && m.tipo !== FM.tipo) return false;
        if (FM.ini && m.data < FM.ini) return false;
        if (FM.fim && m.data > FM.fim) return false;
        if (q && !norm(m.nome + " " + m.obs).includes(q)) return false;
        return true;
    }).sort(function (a, b) { return b.ts - a.ts; });
}

function listaMovs() {
    var el = $("#m-lista");
    if (!el) return;
    el.innerHTML = tabelaMovs(movsFiltrados().slice(0, 500), false);
}

function vMovimentos() {
    $("#app").innerHTML = titulo("Movimentações", "Histórico de entradas, vendas, perdas e ajustes") +
        "<div class=\"filtros\"><select id=\"m-tipo\"><option value=\"\">Todos</option>" +
        Object.keys(NOMES).map(function (k) {
            return "<option value=\"" + k + "\">" + NOMES[k] + "</option>";
        }).join("") + "</select><input id=\"m-q\" placeholder=\"Buscar produto ou observação\">" +
        "<input id=\"m-ini\" type=\"date\"><input id=\"m-fim\" type=\"date\">" +
        "</div><div id=\"m-lista\"></div>";

    listaMovs();
}

/* ==================================================
   PERDAS E AJUSTES
================================================== */

function formPerda() {
    return opcoesProdutos() +
        "<div class=\"campo\"><label>Produto</label><input id=\"x-prod\" list=\"dl-prod\"></div>" +
        "<div class=\"linha\"><div class=\"campo\"><label>Tipo</label><select id=\"x-tipo\">" +
        "<option value=\"perda\">Perda</option><option value=\"ajuste-\">Diminuir estoque</option>" +
        "<option value=\"ajuste+\">Aumentar estoque</option></select></div>" +
        "<div class=\"campo\"><label>Quantidade</label><input id=\"x-qtd\" type=\"number\" min=\"1\"></div></div>" +
        "<div class=\"campo\"><label>Motivo</label><input id=\"x-mot\" placeholder=\"Motivo\"></div>" +
        "<div class=\"campo\"><label>Observação</label><input id=\"x-obs\"></div>";
}

async function salvarPerda() {
    var p = achaProduto($("#x-prod").value);
    var q = Math.floor(num($("#x-qtd").value));
    var tipo = $("#x-tipo").value;

    if (!p || q <= 0) {
        aviso("Informe produto e quantidade.", true);
        return false;
    }

    if (tipo !== "ajuste+" && q > p.estoque) {
        aviso("Estoque insuficiente.", true);
        return false;
    }

    var observacao = (tipo === "perda" ? "[PERDA]" : "[AJUSTE]") +
        " CUSTO=" + Number(p.custo || 0).toFixed(2) +
        " | MOTIVO=" + $("#x-mot").value +
        " | " + $("#x-obs").value;

    try {
        await requisicaoAPI("/estoque/movimentacoes", "POST", {
            produto_id: Number(p.id),
            tipo: tipo === "perda" || tipo === "ajuste-" ? "ajuste" : "ajuste",
            quantidade: tipo === "ajuste-" ? -q : q,
            observacao: observacao
        });

        await carregarDadosAPI();
        fecharModal();
        render();
        aviso("Movimentação registrada.");
        return true;
    } catch (e) {
        aviso(e.message, true);
        return false;
    }
}

/* ==================================================
   FINANCEIRO
================================================== */

function intervalo(tipo, ini, fim) {
    var d = new Date();
    var inicio = new Date(d);
    var final = new Date(d);

    if (tipo === "hoje") {
        return [hoje(), hoje()];
    }

    if (tipo === "7") inicio.setDate(d.getDate() - 6);
    else if (tipo === "30") inicio.setDate(d.getDate() - 29);
    else if (tipo === "mes") inicio.setDate(1);
    else if (tipo === "mespassado") {
        inicio = new Date(d.getFullYear(), d.getMonth() - 1, 1);
        final = new Date(d.getFullYear(), d.getMonth(), 0);
    }
    else if (tipo === "ano") inicio = new Date(d.getFullYear(), 0, 1);
    else if (tipo === "tudo") return ["2000-01-01", "2999-12-31"];
    else if (tipo === "custom") return [ini || hoje(), fim || hoje()];

    return [dataISO(inicio), dataISO(final)];
}

function dataISO(d) {
    return d.getFullYear() + "-" +
        String(d.getMonth() + 1).padStart(2, "0") + "-" +
        String(d.getDate()).padStart(2, "0");
}

function vFinanceiro() {
    var iv = intervalo(PER.tipo, PER.ini, PER.fim);
    var r = resumo(iv[0], iv[1]);

    $("#app").innerHTML = titulo("Financeiro", "Resumo financeiro do período") +
        "<div class=\"filtros\"><select id=\"per-tipo\">" +
        [["hoje", "Hoje"], ["7", "Últimos 7 dias"], ["30", "Últimos 30 dias"],
        ["mes", "Este mês"], ["mespassado", "Mês passado"], ["ano", "Este ano"],
        ["tudo", "Todo período"], ["custom", "Personalizado"]].map(function (o) {
            return "<option value=\"" + o[0] + "\"" +
                (PER.tipo === o[0] ? " selected" : "") + ">" +
                o[1] + "</option>";
        }).join("") + "</select>" +
        (PER.tipo === "custom" ?
            "<input id=\"per-ini\" type=\"date\" value=\"" + esc(PER.ini) +
            "\"><input id=\"per-fim\" type=\"date\" value=\"" + esc(PER.fim) + "\">" : "") +
        "</div><div class=\"kpis\">" +
        kpi("Receita de vendas", R(r.receita), r.nVendas + " venda(s)", "") +
        kpi("Custo vendido", R(r.cmv), "", "roxo") +
        kpi("Lucro bruto", R(r.bruto), "Margem " + r.margem.toFixed(1) + "%", "") +
        kpi("Perdas", R(r.perdas), "", "verm") +
        kpi("Despesas locais", R(r.despesas), "", "verm") +
        kpi("Resultado líquido", R(r.liquido), "", r.liquido >= 0 ? "pos" : "neg") +
        kpi("Compras", R(r.compras), "", "am") +
        "</div><h2 class=\"sec\">Despesas</h2>" +
        "<div class=\"filtros\"><input id=\"d-desc\" placeholder=\"Descrição\">" +
        "<input id=\"d-val\" type=\"number\" min=\"0\" step=\"0.01\" placeholder=\"Valor\">" +
        "<input id=\"d-data\" type=\"date\" value=\"" + hoje() + "\">" +
        "<button class=\"btn\" data-acao=\"add-desp\">Lançar despesa</button></div>" +
        "<div class=\"rolar\"><table><tr><th>Data</th><th>Descrição</th><th>Valor</th><th></th></tr>" +
        E.despesas.filter(function (d) {
            return d.data >= iv[0] && d.data <= iv[1];
        }).map(function (d) {
            return "<tr><td>" + fmtData(d.data) + "</td><td>" +
                esc(d.descricao) + "</td><td>" + R(d.valor) +
                "</td><td><button class=\"btn peq verm\" data-acao=\"del-desp\" data-id=\"" +
                esc(d.id) + "\">Excluir</button></td></tr>";
        }).join("") + "</table></div>";
}

/* ==================================================
   CONFIGURAÇÕES
================================================== */

function vConfig() {
    $("#app").innerHTML = titulo("Ajustes e backup", "Configurações locais do sistema") +
        "<div class=\"grid2\"><div class=\"painel\"><h3>Backup</h3>" +
        "<p class=\"mm\">O backup inclui despesas e configurações locais. Produtos e estoque continuam no servidor.</p>" +
        "<button class=\"btn\" data-acao=\"backup\">Baixar backup</button></div>" +
        "<div class=\"painel\"><h3>Dados da loja</h3><input id=\"c-loja\" value=\"" +
        esc(E.loja) + "\"><button class=\"btn\" data-acao=\"salvar-loja\">Salvar</button></div>" +
        "<div class=\"painel\"><h3>Categorias</h3><p>" +
        E.categorias.map(esc).join(", ") + "</p>" +
        "<input id=\"c-nova\" placeholder=\"Nova categoria\">" +
        "<button class=\"btn\" data-acao=\"add-cat\">Adicionar</button></div>" +
        "<div class=\"painel\"><h3>Acesso</h3><p class=\"mm\">Logado como " +
        esc(USUARIO.nome || USUARIO.usuario || "") + "</p>" +
        "<button class=\"btn verm\" data-acao=\"sair\">Sair</button></div></div>";
}

/* ==================================================
   MODAIS
================================================== */

function abrirModal(tituloModal, conteudo, textoBotao, callback) {
    $("#modal").innerHTML = "<h2>" + esc(tituloModal) + "</h2>" +
        conteudo + "<div class=\"acoes\" style=\"margin-top:18px\">" +
        "<button class=\"btn sec\" data-acao=\"fechar\">Cancelar</button>" +
        "<button class=\"btn\" data-acao=\"modal-ok\">" +
        esc(textoBotao || "Confirmar") + "</button></div>";

    modalOk = callback;
    $("#modal-fundo").hidden = false;
}

function fecharModal() {
    if ($("#modal-fundo")) $("#modal-fundo").hidden = true;
    modalOk = null;
}

/* ==================================================
   CSV E DOWNLOAD
================================================== */

function vc(v) {
    return String(v == null ? "" : v).replace(".", ",");
}

function baixarArquivo(nome, conteudo, tipo) {
    var blob = new Blob([conteudo], { type: tipo || "text/plain;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = nome;
    a.click();
    URL.revokeObjectURL(url);
}

function baixarCSV(nome, linhas) {
    var csv = "\uFEFF" + linhas.map(function (l) {
        return l.map(function (v) {
            return '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
        }).join(";");
    }).join("\r\n");

    baixarArquivo(nome, csv, "text/csv;charset=utf-8");
}

/* ==================================================
   LOGIN
================================================== */

function telaLogin() {
    $("#login").innerHTML =
        "<div class=\"login-card\"><img src=\"logo.png\" alt=\"Limpeza Total\" style=\"height:70px;margin-bottom:10px\">" +
        "<h2>Acesso restrito</h2><p class=\"mm\">Entre com seu usuário e senha.</p>" +
        "<div class=\"campo\"><label>Usuário</label><input id=\"l-user\" autocomplete=\"username\"></div>" +
        "<div class=\"campo\"><label>Senha</label><input id=\"l-s1\" type=\"password\" autocomplete=\"current-password\"></div>" +
        "<button class=\"btn\" data-acao=\"l-entrar\" style=\"width:100%\">Entrar</button>" +
        "<div id=\"l-erro\" class=\"neg\"></div></div>";

    $("#login").hidden = false;
    document.body.classList.add("bloqueado");
}

async function entrar() {
    var usuario = $("#l-user").value.trim();
    var senha = $("#l-s1").value;

    if (!usuario || !senha) {
        $("#l-erro").textContent = "Informe usuário e senha.";
        return;
    }

    try {
        var r = await requisicaoAPI("/login", "POST", {
            usuario: usuario,
            senha: senha
        });

        TOKEN = r.token;
        USUARIO = r.usuario || {};

        sessionStorage.setItem("limpezaToken", TOKEN);
        sessionStorage.setItem("limpezaUsuario", JSON.stringify(USUARIO));

        iniciou = false;
        await liberar();
    } catch (e) {
        $("#l-erro").textContent = e.message;
    }
}

async function sair() {
    try {
        await requisicaoAPI("/logout", "POST");
    } catch (e) {}

    TOKEN = "";
    USUARIO = {};
    iniciou = false;
    sessionStorage.removeItem("limpezaToken");
    sessionStorage.removeItem("limpezaUsuario");
    telaLogin();
}


async function liberar() {
    try {
        if (!TOKEN) {
            telaLogin();
            return;
        }

        var sessao = await requisicaoAPI("/me", "GET");

        USUARIO = sessao.usuario || USUARIO;

        sessionStorage.setItem("limpezaUsuario", JSON.stringify(USUARIO));

        carregarLocal();
        await carregarDadosAPI();

        $("#login").hidden = true;
        document.body.classList.remove("bloqueado");

        iniciou = true;
        render();

    } catch (e) {
        TOKEN = "";
        USUARIO = {};
        iniciou = false;

        sessionStorage.removeItem("limpezaToken");
        sessionStorage.removeItem("limpezaUsuario");

        telaLogin();

        var erro = $("#l-erro");
        if (erro) {
            erro.textContent = "Falha ao validar acesso: " + e.message;
        }
    }
}


/* ==================================================
   AÇÕES
================================================== */

var ACOES = {
    "l-entrar": entrar,
    "sair": sair,
    "ir": function (el) { irPara(el.dataset.v); },
    "novo-produto": function () { abrirProduto(); },
    "editar": function (el) { abrirProduto(el.dataset.id); },

    "excluir-prod": async function (el) {
        var p = prod(el.dataset.id);
        if (!p || !confirm("Arquivar o produto " + p.nome + "?")) return;

        try {
            await requisicaoAPI("/produtos/" + p.id, "DELETE");
            await carregarDadosAPI();
            render();
            aviso("Produto arquivado.");
        } catch (e) {
            aviso(e.message, true);
        }
    },

    "salvar-entrada": salvarEntrada,
    "add-item": addItem,
    "fechar-venda": fecharVenda,

    "rm-item": function (el) {
        itensVenda.splice(Number(el.dataset.k), 1);
        desenhaItens();
    },

    "perda": function () {
        abrirModal("Registrar perda ou ajuste", formPerda(), "Registrar", salvarPerda);
    },

    "fechar": fecharModal,

    "modal-ok": async function () {
        if (!modalOk) return;
        var resultado = await modalOk();
        if (resultado !== false) fecharModal();
    },

    "add-desp": function () {
        var descricao = $("#d-desc").value.trim();
        var valor = num($("#d-val").value);

        if (!descricao || valor <= 0) return aviso("Informe descrição e valor.", true);

        E.despesas.push({
            id: uid(),
            data: $("#d-data").value || hoje(),
            descricao: descricao,
            valor: valor
        });

        salvar();
        render();
        aviso("Despesa lançada localmente.");
    },

    "del-desp": function (el) {
        if (!confirm("Excluir esta despesa local?")) return;
        E.despesas = E.despesas.filter(function (d) {
            return String(d.id) !== String(el.dataset.id);
        });
        salvar();
        render();
    },

    "salvar-loja": function () {
        E.loja = $("#c-loja").value.trim() || "Limpeza Total";
        salvar();
        aviso("Nome salvo.");
    },

    "add-cat": function () {
        var c = $("#c-nova").value.trim();
        if (!c) return;
        if (!E.categorias.includes(c)) E.categorias.push(c);
        salvar();
        render();
    },

    "backup": function () {
        baixarArquivo("backup_limpeza_total_" + hoje() + ".json",
            JSON.stringify({
                loja: E.loja,
                despesas: E.despesas,
                categorias: E.categorias,
                custos: JSON.parse(localStorage.getItem("limpezaCustos") || "{}")
            }, null, 2), "application/json");
    },

    "csv-produtos": function () {
        var linhas = [["Nome", "Categoria", "Preço", "Estoque", "Custo"]];
        ativos().forEach(function (p) {
            linhas.push([p.nome, p.categoria, vc(p.preco),
                p.estoque, vc(p.custo)]);
        });
        baixarCSV("produtos_" + hoje() + ".csv", linhas);
    },

    "csv-movs": function () {
        var linhas = [["Data", "Tipo", "Produto", "Quantidade", "Observação"]];
        movsFiltrados().forEach(function (m) {
            linhas.push([fmtData(m.data), m.tipo, m.nome, m.delta, m.obs]);
        });
        baixarCSV("movimentacoes_" + hoje() + ".csv", linhas);
    },

    "imprimir": function () { window.print(); }
};

/* ==================================================
   EVENTOS
================================================== */

document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-acao]");
    if (!el) return;

    e.preventDefault();

    var fn = ACOES[el.dataset.acao];
    if (fn) fn(el);
});

document.addEventListener("input", function (e) {
    var id = e.target.id;

    if (id === "f-q") {
        F.q = e.target.value;
        listaProdutos();
    }

    if (id === "m-q") {
        FM.q = e.target.value;
        listaMovs();
    }

    if (id === "e-prod") entradaSelecionar(achaProduto(e.target.value));

    if (id === "e-qtd" || id === "e-custo") totalEntrada();

    if (id === "v-desc") totalVenda();

    if (id === "v-prod") {
        var p = achaProduto(e.target.value);
        if (p) {
            $("#v-preco").value = p.preco;
            $("#v-info").hidden = false;
            $("#v-info").textContent = "Estoque disponível: " + p.estoque;
        }
    }
});

document.addEventListener("change", function (e) {
    var id = e.target.id;

    if (id === "f-cat") {
        F.cat = e.target.value;
        listaProdutos();
    }

    if (id === "f-sit") {
        F.sit = e.target.value;
        listaProdutos();
    }

    if (id === "m-tipo") {
        FM.tipo = e.target.value;
        listaMovs();
    }

    if (id === "m-ini") {
        FM.ini = e.target.value;
        listaMovs();
    }

    if (id === "m-fim") {
        FM.fim = e.target.value;
        listaMovs();
    }

    if (id === "per-tipo") {
        PER.tipo = e.target.value;
        vFinanceiro();
    }

    if (id === "p-img") {
        var file = e.target.files[0];
        if (file) {
            lerImagem(file).then(function (imagem) {
                imgTemp = imagem;
                $("#prev-img").innerHTML = "<img src=\"" + esc(imagem) + "\">";
            }).catch(function () {
                aviso("Erro ao carregar imagem.", true);
            });
        }
    }
});

document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") fecharModal();

    if (e.key === "Enter" && e.target.id === "l-s1") entrar();

    if (e.key === "Enter" && e.target.id === "v-prod") {
        e.preventDefault();
        $("#v-qtd").focus();
    }

    if (e.key === "Enter" && e.target.id === "v-qtd") {
        e.preventDefault();
        addItem();
    }
});

if ($("#modal-fundo")) {
    $("#modal-fundo").addEventListener("mousedown", function (e) {
        if (e.target.id === "modal-fundo") fecharModal();
    });
}

function buscaGlobal() {
    var campo = $("#busca-global");
    if (!campo) return;
    F.q = campo.value;
    F.cat = "";
    F.sit = "";
    irPara("produtos");
}

if ($("#busca-btn")) {
    $("#busca-btn").addEventListener("click", buscaGlobal);
}

if ($("#busca-global")) {
    $("#busca-global").addEventListener("keydown", function (e) {
        if (e.key === "Enter") buscaGlobal();
    });
}

window.addEventListener("hashchange", render);

if (TOKEN) liberar();
else telaLogin();

})();
