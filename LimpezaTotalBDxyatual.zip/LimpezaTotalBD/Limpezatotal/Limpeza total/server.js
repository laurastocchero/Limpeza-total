
const http = require("http");
const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");
const crypto = require("crypto");
const { promisify } = require("util");

const scrypt = promisify(crypto.scrypt);

const conexao = {
    host: "localhost",
    user: "limpeza_app",
    password: process.env.DB_PASSWORD,
    database: "limpeza_total",
    port: 3306
};

const banco = mysql.createPool({
    ...conexao,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

const sessoes = new Map();

const PASTA_IMAGENS = path.resolve(__dirname, "..", "imagens");
const LIMITE_CORPO = 8 * 1024 * 1024;

/* ========== RESPOSTAS ========== */

function responder(res, status, dados) {
    if (res.headersSent) return;

    res.writeHead(status, {
        "Content-Type": "application/json; charset=utf-8"
    });

    res.end(JSON.stringify(dados));
}

/* ========== LEITURA DO CORPO ========== */

function lerCorpo(req) {
    return new Promise((resolve, reject) => {
        let corpo = "";
        let excedeuLimite = false;

        req.on("data", parte => {
            if (excedeuLimite) return;

            corpo += parte;

            if (Buffer.byteLength(corpo, "utf8") > LIMITE_CORPO) {
                excedeuLimite = true;
                reject(new Error("Corpo da requisição muito grande."));
            }
        });

        req.on("end", () => {
            if (excedeuLimite) return;

            try {
                resolve(corpo ? JSON.parse(corpo) : {});
            } catch {
                reject(new Error("JSON inválido."));
            }
        });

        req.on("error", reject);
    });
}

/* ========== SENHAS ========== */

async function gerarSenha(senha) {
    const sal = crypto.randomBytes(16).toString("hex");
    const hash = await scrypt(senha, sal, 64);

    return `${sal}:${hash.toString("hex")}`;
}

async function conferirSenha(senha, armazenada) {
    try {
        const [sal, hashSalvo] = armazenada.split(":");
        const hash = await scrypt(senha, sal, 64);
        const original = Buffer.from(hashSalvo, "hex");

        return original.length === hash.length &&
            crypto.timingSafeEqual(hash, original);
    } catch {
        return false;
    }
}

/* ========== SESSÕES E PERMISSÕES ========== */

function obterSessao(req) {
    const autorizacao = req.headers.authorization || "";

    if (!autorizacao.startsWith("Bearer ")) {
        return null;
    }

    const token = autorizacao.substring(7);
    const sessao = sessoes.get(token);

    if (!sessao) return null;

    if (sessao.expira < Date.now()) {
        sessoes.delete(token);
        return null;
    }

    return sessao;
}

function exigirLogin(req, res) {
    const usuario = obterSessao(req);

    if (!usuario) {
        responder(res, 401, {
            erro: "Faça login para continuar."
        });

        return null;
    }

    return usuario;
}

function exigirDono(req, res) {
    const usuario = exigirLogin(req, res);

    if (!usuario) return null;

    if (usuario.tipo !== "dono") {
        responder(res, 403, {
            erro: "Somente o dono pode realizar esta operação."
        });

        return null;
    }

    return usuario;
}

/* ========== VALIDAÇÕES ========== */

function numeroValido(valor) {
    return valor !== undefined &&
        valor !== null &&
        valor !== "" &&
        Number.isFinite(Number(valor));
}

/* ========== IMAGENS ========== */

function servirImagem(req, res, caminho) {
    let nome;

    try {
        nome = path.basename(decodeURIComponent(caminho));
    } catch {
        res.writeHead(400);
        res.end("Nome de imagem inválido.");
        return;
    }

    const extensao = path.extname(nome).toLowerCase();

    const tipos = {
        ".jpeg": "image/jpeg",
        ".jpg": "image/jpeg",
        ".png": "image/png",
        ".webp": "image/webp",
        ".gif": "image/gif"
    };

    if (!tipos[extensao]) {
        res.writeHead(415);
        res.end("Formato de imagem não permitido.");
        return;
    }

    const arquivo = path.join(PASTA_IMAGENS, nome);

    fs.stat(arquivo, (erro, info) => {
        if (erro || !info.isFile()) {
            res.writeHead(404);
            res.end("Imagem não encontrada.");
            return;
        }

        res.writeHead(200, {
            "Content-Type": tipos[extensao],
            "Content-Length": info.size,
            "Cache-Control": "public, max-age=86400"
        });

        const leitura = fs.createReadStream(arquivo);

        leitura.on("error", () => {
            if (!res.headersSent) {
                res.writeHead(500);
                res.end("Erro ao carregar imagem.");
            } else {
                res.destroy();
            }
        });

        leitura.pipe(res);
    });
}

/* ========== SERVIDOR ========== */

const servidor = http.createServer(async (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");

    res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, PUT, PATCH, DELETE, OPTIONS"
    );

    res.setHeader(
        "Access-Control-Allow-Headers",
        "Content-Type, Authorization"
    );

    if (req.method === "OPTIONS") {
        res.writeHead(204);
        res.end();
        return;
    }

    const url = new URL(req.url, "http://localhost");
    const rota = url.pathname;

    try {

        /* ========== ARQUIVOS DE IMAGEM ========== */

        if (rota.startsWith("/imagens/") && req.method === "GET") {
            const caminhoImagem = rota.substring("/imagens/".length);

            servirImagem(req, res, caminhoImagem);
            return;
        }

        /* ========== TESTE DA API ========== */

        if (rota === "/api/status" && req.method === "GET") {
            responder(res, 200, {
                mensagem: "API Limpeza Total funcionando!"
            });

            return;
        }

        /* ========== CRIAR PRIMEIRO DONO ========== */

        if (
            rota === "/api/inicializar-dono" &&
            req.method === "POST"
        ) {
            const dados = await lerCorpo(req);

            if (
                !dados.nome ||
                !dados.usuario ||
                !dados.senha ||
                dados.senha.length < 8
            ) {
                responder(res, 400, {
                    erro: "Informe nome, usuário e senha com pelo menos 8 caracteres."
                });

                return;
            }

            const [usuarios] = await banco.execute(
                "SELECT COUNT(*) AS total FROM usuarios"
            );

            if (usuarios[0].total > 0) {
                responder(res, 403, {
                    erro: "O primeiro dono já foi cadastrado."
                });

                return;
            }

            const senhaHash = await gerarSenha(dados.senha);

            await banco.execute(
                `INSERT INTO usuarios
                 (nome, usuario, senha, tipo, ativo)
                 VALUES (?, ?, ?, 'dono', TRUE)`,
                [dados.nome, dados.usuario, senhaHash]
            );

            responder(res, 201, {
                mensagem: "Primeiro dono cadastrado com sucesso."
            });

            return;
        }

        /* ========== LOGIN ========== */

        if (rota === "/api/login" && req.method === "POST") {
            const dados = await lerCorpo(req);

            const [usuarios] = await banco.execute(
                `SELECT id, nome, usuario, senha, tipo, ativo
                 FROM usuarios
                 WHERE usuario = ?`,
                [dados.usuario || ""]
            );

            if (
                !usuarios.length ||
                !usuarios[0].ativo ||
                !(await conferirSenha(
                    dados.senha || "",
                    usuarios[0].senha
                ))
            ) {
                responder(res, 401, {
                    erro: "Usuário ou senha inválidos."
                });

                return;
            }

            const usuario = usuarios[0];
            const token = crypto.randomBytes(32).toString("hex");

            sessoes.set(token, {
                id: usuario.id,
                nome: usuario.nome,
                usuario: usuario.usuario,
                tipo: usuario.tipo,
                expira: Date.now() + 8 * 60 * 60 * 1000
            });

            responder(res, 200, {
                mensagem: "Login realizado com sucesso.",
                token,
                usuario: {
                    id: usuario.id,
                    nome: usuario.nome,
                    usuario: usuario.usuario,
                    tipo: usuario.tipo
                }
            });

            return;
        }

        /* ========== LOGOUT ========== */

        if (rota === "/api/logout" && req.method === "POST") {
            const token = (req.headers.authorization || "")
                .replace("Bearer ", "");

            sessoes.delete(token);

            responder(res, 200, {
                mensagem: "Sessão encerrada."
            });

            return;
        }

        /* ========== USUÁRIO LOGADO ========== */

        if (rota === "/api/me" && req.method === "GET") {
            const usuario = exigirLogin(req, res);

            if (!usuario) return;

            responder(res, 200, { usuario });
            return;
        }

        /* ========== LISTAR PRODUTOS ========== */

        if (rota === "/api/produtos" && req.method === "GET") {
            const [produtos] = await banco.execute(
                `SELECT id, nome, descricao, categoria,
                        preco, estoque, imagem
                 FROM produtos
                 WHERE ativo = 1
                 ORDER BY id`
            );

            responder(res, 200, produtos);
            return;
        }

        /* ========== CADASTRAR PRODUTO ========== */

        if (rota === "/api/produtos" && req.method === "POST") {
            if (!exigirLogin(req, res)) return;

            const dados = await lerCorpo(req);

            if (
                !dados.nome ||
                !numeroValido(dados.preco) ||
                Number(dados.preco) < 0
            ) {
                responder(res, 400, {
                    erro: "Nome e preço válido são obrigatórios."
                });

                return;
            }

            const [resultado] = await banco.execute(
                `INSERT INTO produtos
                 (nome, descricao, categoria, preco, estoque, imagem)
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [
                    dados.nome,
                    dados.descricao || "",
                    dados.categoria || null,
                    Number(dados.preco),
                    numeroValido(dados.estoque)
                        ? Number(dados.estoque)
                        : 0,
                    dados.imagem || null
                ]
            );

            responder(res, 201, {
                mensagem: "Produto cadastrado.",
                id: resultado.insertId
            });

            return;
        }

        /* ========== IDENTIFICAR PRODUTO ========== */

        const rotaProduto = rota.match(/^\/api\/produtos\/(\d+)$/);

        /* ========== EDITAR PRODUTO ========== */

        if (rotaProduto && req.method === "PUT") {
            if (!exigirLogin(req, res)) return;

            const id = Number(rotaProduto[1]);
            const dados = await lerCorpo(req);

            if (
                !dados.nome ||
                !numeroValido(dados.preco) ||
                Number(dados.preco) < 0
            ) {
                responder(res, 400, {
                    erro: "Informe nome e preço válido."
                });

                return;
            }

            const [resultado] = await banco.execute(
                `UPDATE produtos
                 SET nome = ?, descricao = ?, categoria = ?,
                     preco = ?, imagem = ?
                 WHERE id = ?`,
                [
                    dados.nome,
                    dados.descricao || "",
                    dados.categoria || null,
                    Number(dados.preco),
                    dados.imagem || null,
                    id
                ]
            );

            if (!resultado.affectedRows) {
                responder(res, 404, {
                    erro: "Produto não encontrado."
                });

                return;
            }

            responder(res, 200, {
                mensagem: "Produto atualizado."
            });

            return;
        }

        /* ========== INATIVAR PRODUTO ========== */

        if (rotaProduto && req.method === "DELETE") {
            if (!exigirLogin(req, res)) return;

            const [resultado] = await banco.execute(
                `UPDATE produtos
                 SET ativo = 0
                 WHERE id = ? AND ativo = 1`,
                [Number(rotaProduto[1])]
            );

            if (!resultado.affectedRows) {
                responder(res, 404, {
                    erro: "Produto não encontrado."
                });

                return;
            }

            responder(res, 200, {
                mensagem: "Produto inativado com sucesso."
            });

            return;
        }

        /* ========== LISTAR USUÁRIOS ========== */

        if (rota === "/api/usuarios" && req.method === "GET") {
            if (!exigirDono(req, res)) return;

            const [usuarios] = await banco.execute(
                `SELECT id, nome, usuario, tipo, ativo, criado_em
                 FROM usuarios
                 ORDER BY id`
            );

            responder(res, 200, usuarios);
            return;
        }

        /* ========== CADASTRAR FUNCIONÁRIO ========== */

        if (rota === "/api/usuarios" && req.method === "POST") {
            if (!exigirDono(req, res)) return;

            const dados = await lerCorpo(req);

            if (
                !dados.nome ||
                !dados.usuario ||
                !dados.senha ||
                dados.senha.length < 8
            ) {
                responder(res, 400, {
                    erro: "Informe nome, usuário e senha com pelo menos 8 caracteres."
                });

                return;
            }

            const senhaHash = await gerarSenha(dados.senha);

            await banco.execute(
                `INSERT INTO usuarios
                 (nome, usuario, senha, tipo, ativo)
                 VALUES (?, ?, ?, 'funcionario', TRUE)`,
                [dados.nome, dados.usuario, senhaHash]
            );

            responder(res, 201, {
                mensagem: "Funcionário cadastrado."
            });

            return;
        }

        /* ========== EDITAR OU BLOQUEAR FUNCIONÁRIO ========== */

        const rotaUsuario = rota.match(/^\/api\/usuarios\/(\d+)$/);

        if (
            rotaUsuario &&
            (req.method === "PUT" || req.method === "PATCH")
        ) {
            const dono = exigirDono(req, res);

            if (!dono) return;

            const id = Number(rotaUsuario[1]);

            if (id === dono.id) {
                responder(res, 400, {
                    erro: "Não é permitido alterar a própria conta por esta rota."
                });

                return;
            }

            const [existentes] = await banco.execute(
                "SELECT id, tipo FROM usuarios WHERE id = ?",
                [id]
            );

            if (
                !existentes.length ||
                existentes[0].tipo !== "funcionario"
            ) {
                responder(res, 404, {
                    erro: "Funcionário não encontrado."
                });

                return;
            }

            const dados = await lerCorpo(req);

            if (req.method === "PATCH") {
                if (typeof dados.ativo !== "boolean") {
                    responder(res, 400, {
                        erro: "Informe ativo como true ou false."
                    });

                    return;
                }

                await banco.execute(
                    "UPDATE usuarios SET ativo = ? WHERE id = ?",
                    [dados.ativo, id]
                );

                responder(res, 200, {
                    mensagem: "Situação do funcionário atualizada."
                });

                return;
            }

            if (!dados.nome || !dados.usuario) {
                responder(res, 400, {
                    erro: "Nome e usuário são obrigatórios."
                });

                return;
            }

            if (dados.senha && dados.senha.length < 8) {
                responder(res, 400, {
                    erro: "A senha precisa ter pelo menos 8 caracteres."
                });

                return;
            }

            if (dados.senha) {
                const senhaHash = await gerarSenha(dados.senha);

                await banco.execute(
                    `UPDATE usuarios
                     SET nome = ?, usuario = ?, senha = ?
                     WHERE id = ?`,
                    [dados.nome, dados.usuario, senhaHash, id]
                );
            } else {
                await banco.execute(
                    `UPDATE usuarios
                     SET nome = ?, usuario = ?
                     WHERE id = ?`,
                    [dados.nome, dados.usuario, id]
                );
            }

            responder(res, 200, {
                mensagem: "Funcionário atualizado."
            });

            return;
        }

        /* ========== HISTÓRICO DE ESTOQUE ========== */

        if (
            rota === "/api/estoque/movimentacoes" &&
            req.method === "GET"
        ) {
            if (!exigirLogin(req, res)) return;

            const [movimentacoes] = await banco.execute(
                `SELECT m.id, m.produto_id, p.nome AS produto,
                        m.tipo, m.quantidade, m.observacao,
                        m.usuario_id, u.nome AS usuario, m.criado_em
                 FROM movimentacoes_estoque m
                 INNER JOIN produtos p ON p.id = m.produto_id
                 LEFT JOIN usuarios u ON u.id = m.usuario_id
                 ORDER BY m.id DESC`
            );

            responder(res, 200, movimentacoes);
            return;
        }

        /* ========== REGISTRAR MOVIMENTAÇÃO ========== */

        if (
            rota === "/api/estoque/movimentacoes" &&
            req.method === "POST"
        ) {
            const usuario = exigirLogin(req, res);

            if (!usuario) return;

            const dados = await lerCorpo(req);
            const produtoId = Number(dados.produto_id);
            const quantidade = Number(dados.quantidade);

            if (
                !Number.isInteger(produtoId) ||
                produtoId <= 0 ||
                !Number.isInteger(quantidade) ||
                quantidade === 0 ||
                !["entrada", "saida", "ajuste"].includes(dados.tipo)
            ) {
                responder(res, 400, {
                    erro: "Informe produto, tipo e quantidade inteira válida. Ajustes podem ser positivos ou negativos."
                });

                return;
            }

            const conexaoMov = await banco.getConnection();

            try {
                await conexaoMov.beginTransaction();

                const [produtos] = await conexaoMov.execute(
                    "SELECT estoque FROM produtos WHERE id = ? FOR UPDATE",
                    [produtoId]
                );

                if (!produtos.length) {
                    await conexaoMov.rollback();

                    responder(res, 404, {
                        erro: "Produto não encontrado."
                    });

                    return;
                }

                const atual = Number(produtos[0].estoque);
                let variacao = quantidade;

                if (dados.tipo === "saida") {
                    if (quantidade < 0) {
                        await conexaoMov.rollback();

                        responder(res, 400, {
                            erro: "A saída deve ter quantidade positiva."
                        });

                        return;
                    }

                    variacao = -quantidade;
                }

                if (dados.tipo === "entrada" && quantidade < 0) {
                    await conexaoMov.rollback();

                    responder(res, 400, {
                        erro: "A entrada deve ter quantidade positiva."
                    });

                    return;
                }

                const novoEstoque = atual + variacao;

                if (novoEstoque < 0) {
                    await conexaoMov.rollback();

                    responder(res, 400, {
                        erro: "Estoque insuficiente para esta operação."
                    });

                    return;
                }

                await conexaoMov.execute(
                    "UPDATE produtos SET estoque = ? WHERE id = ?",
                    [novoEstoque, produtoId]
                );

                await conexaoMov.execute(
                    `INSERT INTO movimentacoes_estoque
                     (produto_id, tipo, quantidade, observacao, usuario_id)
                     VALUES (?, ?, ?, ?, ?)`,
                    [
                        produtoId,
                        dados.tipo,
                        quantidade,
                        dados.observacao || null,
                        usuario.id
                    ]
                );

                await conexaoMov.commit();

                responder(res, 201, {
                    mensagem: "Estoque atualizado.",
                    estoque_anterior: atual,
                    estoque_atual: novoEstoque
                });

            } catch (erro) {
                await conexaoMov.rollback();
                throw erro;

            } finally {
                conexaoMov.release();
            }

            return;
        }

        /* ========== ROTA NÃO ENCONTRADA ========== */

        responder(res, 404, {
            erro: "Rota não encontrada."
        });

    } catch (erro) {
        console.error("Erro na API:", erro);

        if (erro.code === "ER_DUP_ENTRY") {
            responder(res, 409, {
                erro: "Esse nome de usuário já está cadastrado."
            });

        } else if (erro.code === "ER_NO_REFERENCED_ROW_2") {
            responder(res, 400, {
                erro: "Produto ou usuário informado não existe."
            });

        } else if (
            erro.message === "JSON inválido." ||
            erro.message === "Corpo da requisição muito grande."
        ) {
            responder(res, 400, {
                erro: erro.message
            });

        } else {
            responder(res, 500, {
                erro: "Erro interno no servidor."
            });
        }
    }
});

/* ========== GARANTIR COLUNA DE IMAGEM ========== */

async function garantirColunaImagem() {
    const [colunas] = await banco.execute(
        "SHOW COLUMNS FROM produtos LIKE 'imagem'"
    );

    if (colunas.length === 0) {
        await banco.execute(
            "ALTER TABLE produtos ADD COLUMN imagem LONGTEXT NULL"
        );

        console.log("Coluna imagem criada na tabela produtos.");
    }
}

/* ========== INICIALIZAÇÃO ========== */

async function iniciar() {
    try {
        if (!conexao.password) {
            throw new Error(
                "A variável DB_PASSWORD não foi configurada."
            );
        }

        const conexaoTeste = await banco.getConnection();

        await conexaoTeste.ping();
        conexaoTeste.release();

        await garantirColunaImagem();

        servidor.listen(3000, () => {
            console.log("API Limpeza Total iniciada!");
            console.log("Endereço: http://localhost:3000/api/status");
            console.log("Imagens: http://localhost:3000/imagens/");
        });

    } catch (erro) {
        console.error(
            "Não foi possível iniciar a API:",
            erro.message
        );

        process.exit(1);
    }
}

iniciar();
